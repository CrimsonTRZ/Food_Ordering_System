<?php
    include'config.php';

    session_start();


    $query = "SELECT * FROM category";
    $db= mysqli_query($conn, $query);

    $query1 = "SELECT a.* , c.* FROM application_form a, category c WHERE a.categoryID = c.categoryID";
    $db1= mysqli_query($conn, $query1);


// Search function (search by category and stall name)
    if (isset($_POST['lookup'])) {
        $search = mysqli_real_escape_string($conn, $_POST['search']);
        $query = mysqli_query($conn, "SELECT * FROM category WHERE category_name  LIKE '%$search%' ");
        $result = mysqli_num_rows($query);
        if ($result > 0) {
            while($row = mysqli_fetch_assoc($query)){
                $ctgID = $row['categoryID'];
                if ($ctgID) {
                    echo '<script>window.location="Category.php?categoryID='.$ctgID.'"</script>';
                }
            }
        }
        $query1 = mysqli_query($conn, "SELECT * FROM application_form WHERE stall_name LIKE '%$search%' ");
        $result1 = mysqli_num_rows($query1);
        if ($result1 > 0) {
            while($row = mysqli_fetch_assoc($query1)){
                $stallName = $row['stall_name'];
                if ($stallName) {
                    echo '<script>window.location="hawker-menu.php?stall_name='.$stallName.'"</script>';
                }
            }
        } else {
            echo "<script>alert('Search result not found. Please try another keyword.')</script>";
        }
    }


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Main Page</title>
    <link rel= "stylesheet" type="text/css" href="mainpage.css">
    <script src="https://kit.fontawesome.com/a0eb58ef8d.js" crossorigin="anonymous"></script>

</head>
<body>
    
   <!-- universal nav bar -->
   <nav>
      <div class="logo">
        <a href="#"><img src="img/logo.jpeg" alt="logo" /></a>
      </div>
      <li class="logoname">Grubs4Grabs</li>
      <ul>
        <div>
          <li><a href="mainpage.php">Home Page</a></li>
          <li><a href="personal-details.php">Profile</a></li>
          <li><a href="cart.php">Cart</a></li>
          <li><a href="join-family.php">Join Our Family</a></li>
          <li><a href="register.php">Sign Up</a></li>
          <li><a href="index.php">Login</a></li>
          <li><a href="logout.php">Sign Out</a></li>
        </div>
        <form action="" class="searchbar" method="post">
          <input type="search" placeholder="Search.." name="search" />
          <button type="submit" name="lookup">
            <i class="fas fa-search"></i>
          </button>
        </form>
      </ul>
   </nav>
   <br>
   <br>
   <center><p id="mainpage-header">What we offer?</p></center>

<!-- Main content -->
<center>
<div class="category-icon">

<?php
      while($result=mysqli_fetch_array($db)){
    ?>
    <div class = "icons">

            <?php
              echo "<ul id='category-box'>";
              echo "<li>". '<img src="data:image/jpeg;base64,'.base64_encode($result['img']).'"alt= "catImg" style="border-radius: 50%"; >'. "</li>";
              echo "<li>". '<a id="category-name" href="Category.php?categoryID=' . $result['categoryID'] . '">' . $result['category_name'] . "</a>" . "</li>";
              echo "</ul>";
            ?>
    </div>
    <?php
      }
?>

</div>
</center>

    <!-- Advertisement slides -->
    <div class="advertisement">
      <!-- Full-width images with numbers -->
      <div class="slide-fade">
        <div class="slidenumber">1 / 3</div>
        <img src="img/slide1.jpg"/>
      </div>

      <div class="slide-fade">
        <div class="slidenumber">2 / 3</div>
        <img src="img/slide2.jpg"/>
      </div>

      <div class="slide-fade">
        <div class="slidenumber">3 / 3</div>
        <img src="img/slide3.jpg"/>
      </div>

      <!-- Previous & Next buttons -->
      <!-- the code is the navigation arrow -->
      <a class="previous" onclick="goSlides(-1)">&#10094;</a>
      <a class="next" onclick="goSlides(1)">&#10095;</a>
    </div>
    <br />


    <!-- hawkers preview -->
    <center>
      <div class="hawker-icon">
        <?php 
            while($result=mysqli_fetch_array($db1)){
              $hawk_img = $result['hawk_img'];
          ?>
          
          <div class = "hawker-icons">
            <ul>
              <li><img src="<?php echo $hawk_img; ?>" alt="hawker pic"></li>
              <?php
                echo "<li>".'<a id="hawker-name" href="hawker-menu.php?stall_name=' . $result['stall_name'] . '">' . $result['stall_name'] . "</a>" . "</li>";
                echo "<li>". $result['category_name'] . "</li>";
              ?>
            </ul>

          </div>
          <?php
            }
          ?>
      </div>
     
    </center>

    
    <div class="about">
      <center>
        <div class="about-info">
          <h3>About Us</h3>
          <p>
            Grubs4Grabs is a hawker food centred application. Due to the current
            pandemic, many businesses have suffered great losses, but the ones
            who suffered the most, are our beloved hawkers. Grubs4Grabs
            sympathises with these self-made chefs and want to revive their
            business to its previous glory.Therefore, all the selections above
            are only composed of hawker food. Enjoy!
          </p>
          <br />
          <p>For further inquries, feel free to contact us @</p>
          <p><i class="fas fa-phone-alt"></i> Contact: +6067-6969-696969</p>
          <p><i class="far fa-envelope"></i> Email: Grubs4Grabs@pukima.com</p>
          <br /><br />
        </div>
        <footer class="copyright">
          Copyright <i class="far fa-copyright"></i> 2021 All Rights Reserved
          Grubs4Grabs
        </footer>
      </center>
    </div>
</body>
</html>

<script>
    var slideIndex = 1;
    displaySlides(slideIndex);

    function currentSlide(n) {
      displaySlides((slideIndex = n));
    }

    function goSlides(n) {
      displaySlides((slideIndex += n));
    }

    function displaySlides(n) {
      var i;
      var slides = document.getElementsByClassName("slide-fade");
      var dots = document.getElementsByClassName("dot");
      if (n > slides.length) {
        slideIndex = 1;
      }
      if (n < 1) {
        slideIndex = slides.length;
      }
      for (i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";
      }
      for (i = 0; i < dots.length; i++) {
        dots[i].className = dots[i].className.replace(" active", "");
      }
      slides[slideIndex - 1].style.display = "block";
      dots[slideIndex - 1].className += " active";
    }
  </script>