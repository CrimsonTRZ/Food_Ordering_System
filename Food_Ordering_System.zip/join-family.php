<?php
    include'config.php';
    
    error_reporting(0);

    session_start();

    if(!isset($_SESSION['Uname'])) {
        header("Location: index.php");
      }

  // Search function (search by category and stall name)
    if (isset($_POST['lookup'])) {
      $search = mysqli_real_escape_string($conn, $_POST['search']);
      $query = mysqli_query($conn, "SELECT * FROM category WHERE category_name  LIKE '%$search%' ");
      $result = mysqli_num_rows($query);
      if ($result > 0) {
          while($row = mysqli_fetch_assoc($query)){
              $ctgID = $row['categoryID'];
              if ($ctgID) {
                  echo '<script>window.location="Category.php?categoryID='.$ctgID.'"</script>';
              }
          }
      }
      $query1 = mysqli_query($conn, "SELECT * FROM application_form WHERE stall_name LIKE '%$search%' ");
      $result1 = mysqli_num_rows($query1);
      if ($result1 > 0) {
          while($row = mysqli_fetch_assoc($query1)){
              $stallName = $row['stall_name'];
              if ($stallName) {
                  echo '<script>window.location="hawker-menu.php?stall_name='.$stallName.'"</script>';
              }
          }
      } else {
          echo "<script>alert('Search result not found. Please try another keyword.')</script>";
      }
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Join_Our_Family</title>
    <link rel="stylesheet" type="text/css" href="join-family.css" />
    <script
    src="https://kit.fontawesome.com/a0eb58ef8d.js"
    crossorigin="anonymous"
  ></script>
    <style>

    </style>
</head>
<body>

    <!-- universal nav bar -->
    <nav>
        <div class="logo">
          <a href="#"><img src="img/logo.jpeg" alt="logo" /></a>
        </div>
        <li class="logoname">Grubs4Grabs</li>
        <ul>
          <div>
            <li><a href="mainpage.php">Home Page</a></li>
            <li><a href="personal-details.php">Profile</a></li>
            <li><a href="cart.php">Cart</a></li>
            <li><a href="join-family.php">Join Our Family</a></li>
            <li><a href="register.php">Sign Up</a></li>
            <li><a href="index.php">Login</a></li>
            <li><a href="logout.php">Sign Out</a></li>
          </div>
          <form action="" class="searchbar" method="post">
            <input type="search" placeholder="Search.." name="search" />
            <button type="submit" name="lookup">
              <i class="fas fa-search"></i>
            </button>
          </form>
        </ul>
    </nav>


        <p style="color:cyan">Want to be a seller? 
            We welcome you to our family! With 3 simple steps, 
            you can start your very own online business with over a thousand of 
            hungry Malaysians hunting for their favourite bites.</p>

        <div class="wrapper">
            <button type="submit" style="background-color: greenyellow; font-size: 25px;" name="hawker-button" id="hawker-button"><a href="application-form.php">Hawker</a></button>
        </div>

        <div style="margin:0 auto;width:45vw"><p style="text-align: left; color:cyan;">
            1. Fill up this application form by clicking on the button above and submit it.<br><br>
            2. After approving, login into your account and edit your catalogue. Press confirm to complete your catalogue.<br><br>
            3. Once your catalogue is completed, your shop is up and ready to go.</p>
        </div>
        
        


    </body>
</html>