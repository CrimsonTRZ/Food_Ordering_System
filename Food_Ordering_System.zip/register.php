<?php
    include'config.php';
    
    error_reporting(0);

    session_start();

    if(isset($_SESSION['new_user'])) {
        header("Location: index.php");
      }

      if(isset($_SESSION['Uname'])) {
        header("Location: mainpage.php");
      }


    if(isset($_POST['register'])){
        $new_user = $_POST['new_user'];
        $new_password = md5($_POST['new_password']);
        $confirm_password = md5($_POST['confirm_password']);
        $new_phone = $_POST['new_phone'];
        $new_email = $_POST['new_email'];
        $streetAdd = $_POST['streetAdd'];
        $postal = $_POST['postal'];
        $city = $_POST['city'];
        $state = $_POST['state'];
        $DOB = $_POST['DOB'];

        if($new_password == $confirm_password){
            $sql = "SELECT * FROM user WHERE username='$new_user' AND password = '$new_password'";
            $result = mysqli_query($conn, $sql);
            if (!$result->num_rows > 0 ) {
                $sql = "INSERT  INTO user (username, password, phone_number, email_address, street_address, postal_code, city, state, Date_of_Birth)
                        VALUES ('$new_user', '$new_password', '$new_phone', '$new_email', '$streetAdd', '$postal', '$city', '$state', '$DOB')";
                $result = mysqli_query($conn, $sql);
                $query = mysqli_query($conn, "SELECT userID FROM user WHERE username = '$new_user'");
                while ($data = mysqli_fetch_assoc($query)) {
                    $userID = $data['userID'];
                    $sql = mysqli_query($conn, "INSERT INTO cart(userID) VALUES ('$userID')");
                }
                $_SESSION['new_user'] = $new_user;
                if ($result) {
                $new_user = "";
                $_POST['new_password'] = "";
                $_POST['confirm_password'] = "";
                $new_phone = "";
                $new_email = "";
                $streetAdd = "";
                $postal = "";
                $city = "";
                $state = "";
                $DOB = "";
                echo "<script>alert('Registration Successful! Proceed to Login.')</script>";
                } else {
                    echo "<script>alert('Something Went Wrong...')</script>";
                }
                
            } else {
                echo "<script>alert('Username or Password Already Exists.')</script>";
            }
        } else {
            echo "<script>alert('Password DOES NOT Match.')</script>";
        }
    }
    
    // Search function (search by category and stall name)
    if (isset($_POST['lookup'])) {
        $search = mysqli_real_escape_string($conn, $_POST['search']);
        $query = mysqli_query($conn, "SELECT * FROM category WHERE category_name  LIKE '%$search%' ");
        $result = mysqli_num_rows($query);
        if ($result > 0) {
            while($row = mysqli_fetch_assoc($query)){
                $ctgID = $row['categoryID'];
                if ($ctgID) {
                    echo '<script>window.location="Category.php?categoryID='.$ctgID.'"</script>';
                }
            }
        }
        $query1 = mysqli_query($conn, "SELECT * FROM application_form WHERE stall_name LIKE '%$search%' ");
        $result1 = mysqli_num_rows($query1);
        if ($result1 > 0) {
            while($row = mysqli_fetch_assoc($query1)){
                $stallName = $row['stall_name'];
                if ($stallName) {
                    echo '<script>window.location="hawker-menu.php?stall_name='.$stallName.'"</script>';
                }
            }
        } else {
            echo "<script>alert('Search result not found. Please try another keyword.')</script>";
        }
      }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration</title>
    <link rel="stylesheet" href="loginregister.css" />
    <script src="https://kit.fontawesome.com/a0eb58ef8d.js" crossorigin="anonymous"></script>
</head>
<body>
    
<!-- universal nav bar -->
    <nav>
        <div class="logo">
          <a href="#"><img src="img/logo.jpeg" alt="logo" /></a>
        </div>
        <li class="logoname">Grubs4Grabs</li>
        <ul>
          <div>
            <li><a href="mainpage.php">Home Page</a></li>
            <li><a href="personal-details.php">Profile</a></li>
            <li><a href="cart.php">Cart</a></li>
            <li><a href="join-family.php">Join Our Family</a></li>
            <li><a href="register.php">Sign Up</a></li>
            <li><a href="index.php">Login</a></li>
            <li><a href="logout.php">Sign Out</a></li>
          </div>
          <form action="" class="searchbar" method="post">
            <input type="search" placeholder="Search.." name="search" />
            <button type="submit" name="lookup">
              <i class="fas fa-search"></i>
            </button>
          </form>
        </ul>
    </nav>

<!-- registration -->
    <div class="container">
        <div class="forms-container">
            <div class="login-register">
                <form action="" method="post" class="register-form">
                    <center><h2 class="title"><u>Register</u></h2></center>
                    <div class="input-field">
                        <input type="text" placeholder="Username" name="new_user" value="<?php echo $_POST["new_user"]; ?>" required />
                    </div>
                    <div class="input-field">
                        <input type="password" placeholder="Password" name="new_password" value="<?php echo $_POST["new_password"]; ?>" required />
                    </div>
                    <div class="input-field">
                        <input type="password" placeholder="Confirm Password" name="confirm_password" value="<?php echo $_POST["confirm_password"]; ?>" required />
                    </div>
                    <div class="input-field">
                        <input type="tel" placeholder="Phone number (60xxxxxxxxx)" name="new_phone" pattern="[0-9]{11}" value="<?php echo $_POST["new_phone"]; ?>" required />
                    </div>
                    <div class="input-field">
                        <input type="email" placeholder="Email Address" name="new_email" value="<?php echo $_POST["new_email"]; ?>" required />
                    </div>
                    <div class="input-field">
                        <input type="text" placeholder="Street Address" name="streetAdd" value="<?php echo $_POST["streetAdd"]; ?>" required />
                    </div>
                    <div class="input-field">
                        <input type="text" placeholder="Postal Code" name="postal" value="<?php echo $_POST["postal"]; ?>" required />
                    </div>
                    <div class="input-field">
                        <input type="text" placeholder="City" name="city" value="<?php echo $_POST["city"]; ?>" required />
                    </div>
                    <div class="input-field">
                        <input type="text" placeholder="State" name="state" value="<?php echo $_POST["state"]; ?>" required />
                    </div>
                    <div class="input-field">
                        <input type="date" placeholder="Date of Birth" name="DOB" value="<?php echo $_POST["DOB"]; ?>" required />
                    </div>
                    <button type = "submit" class= "register" name= "register">Register</button>
                    <p class = "register-fail">Already Registered? <a href="index.php" style="color: #340267; font-weight: bold">Login Here.</a></p>
                    </form>
            </div>
        </div>
    </div>

</body>
</html>