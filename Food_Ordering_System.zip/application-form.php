<?php
    include'config.php';
    
    error_reporting(0);

    session_start();

    if(!isset($_SESSION['Uname'])) {
        header("Location: index.php");
        } else {
            $Uname = $_SESSION['Uname'];
        }

// Search function (search by category and stall name)
    if (isset($_POST['lookup'])) {
      $search = mysqli_real_escape_string($conn, $_POST['search']);
      $query = mysqli_query($conn, "SELECT * FROM category WHERE category_name  LIKE '%$search%' ");
      $result = mysqli_num_rows($query);
      if ($result > 0) {
          while($row = mysqli_fetch_assoc($query)){
              $ctgID = $row['categoryID'];
              if ($ctgID) {
                  echo '<script>window.location="Category.php?categoryID='.$ctgID.'"</script>';
              }
          }
      }
      $query1 = mysqli_query($conn, "SELECT * FROM application_form WHERE stall_name LIKE '%$search%' ");
      $result1 = mysqli_num_rows($query1);
      if ($result1 > 0) {
          while($row = mysqli_fetch_assoc($query1)){
              $stallName = $row['stall_name'];
              if ($stallName) {
                  echo '<script>window.location="hawker-menu.php?stall_name='.$stallName.'"</script>';
              }
          }
      } else {
          echo "<script>alert('Search result not found. Please try another keyword.')</script>";
      }
    }
    

    if(isset($_POST['appli-form'])){
        // upload image file
        $name = $_FILES['file']['name'];
        $target_dir = "img/";
        $target_file = $target_dir . basename($_FILES["file"]["name"]);
        $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
        $extensions_arr = array("jpeg");
        if( in_array($imageFileType,$extensions_arr) ){
            if(move_uploaded_file($_FILES['file']['tmp_name'],$target_dir.$name)){
                $image_base64 = base64_encode(file_get_contents('img/'.$name) );
                $pict = 'data:image/'.$imageFileType.';base64,'.$image_base64;
            }
        }
        $stallname = $_POST['stallname'];
        $name = $_POST['name'];
        $phone = $_POST['phone'];
        $email = $_POST['email'];
        $address = $_POST['pickup_address'];
        $state = $_POST['state'];
        $postal = $_POST['postal'];
        $city = $_POST['city'];
        $category = $_POST['category'];
        $query = mysqli_query($conn, "SELECT * FROM category WHERE category_name = '$category'");
        while ($result = mysqli_fetch_assoc($query)) {
            $catID = $result['categoryID'];
        }
        $query1 = mysqli_query($conn, "SELECT * FROM user WHERE username = '$Uname' ");
        while ($result1 = mysqli_fetch_assoc($query1)) {
            $userID = $result1['userID'];
        }

        $sql = "SELECT * FROM application_form WHERE stall_name='$stallname' OR full_name = '$name'";
        $result = mysqli_query($conn, $sql);
        if (!$result->num_rows > 0 ) {
            $sql1 = mysqli_query($conn, "INSERT INTO `application_form`(`stall_name`, `full_name`, `userID`, `phone_number`, `email`, `pickup_address`, `postal_code`, `city`, `state`, `categoryID`, `hawk_img`) VALUES ('$stallname','$name','$userID','$phone','$email','$address','$postal','$city','$state','$catID','". $pict."')");
            if ($sql1) {
                $stallname = "";
                $name = "";
                $phone = "";
                $email = "";
                $address = "";
                $state = "";
                $postal = "";
                $city = "";
                $category = "";
                $pict = "";
            echo "<script>alert('Application Form Submitted! Please wait for around 7-10 working days for approval.')</script>";
            } else {
                echo "<script>alert('Something Went Wrong...')</script>";
            }
        } else {
            echo "<script>alert('Stall Name or Hawker already exist.')</script>";
        }
    }

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>hawker-application-form</title>
    <link rel="stylesheet" type="text/css" href="application-form.css" />
    <script
    src="https://kit.fontawesome.com/a0eb58ef8d.js"
    crossorigin="anonymous"
  ></script>
</head>
<body>
   <!-- universal nav bar -->
   <nav>
      <div class="logo">
        <a href="#"><img src="img/logo.jpeg" alt="logo" /></a>
      </div>
      <li class="logoname">Grubs4Grabs</li>
      <ul>
        <div>
            <li><a href="mainpage.php">Home Page</a></li>
            <li><a href="personal-details.php">Profile</a></li>
            <li><a href="cart.php">Cart</a></li>
            <li><a href="join-family.php">Join Our Family</a></li>
            <li><a href="register.php">Sign Up</a></li>
            <li><a href="index.php">Login</a></li>
            <li><a href="logout.php">Sign Out</a></li>
        </div>
        <form action="" class="searchbar" method="post">
          <input type="search" placeholder="Search.." name="search" />
          <button type="submit" name="lookup">
            <i class="fas fa-search"></i>
          </button>
        </form>
      </ul>
   </nav>

    <!-- main content -->
    <h3>
        <center>Fill up this form with all the information listed. 
                Please ensure that all information is accurate before submitting. 
                Once submitted, there can be no redo. 
                Duplicated submission will be voided.</center><br>
    </h3>

    <body style="background-color: rgb(253, 200, 103);" >
    <div class="hawker-application-form"; style="margin:0 auto;width:60vw">
        <form action="" method="post" enctype='multipart/form-data'>
            <label for="stallname">Hawker Stall Name: </label>
            <input type="text" name="stallname" id="stallname" placeholder="-Enter Stall Name Here-" required><br><br>
            <label for="name">Full name as per NRIC: </label>
            <input type="text" name="name" id="name" placeholder="-Enter Fullname Here-" required><br><br>
            <label for="phone">Mobile number: </label>
            <input type="tel" name="phone" id="phone" pattern="[0-9]{11}" placeholder="Phone number (60xxxxxxxxx)" required><br><br>
            <label for="email">Email Address: </label>
            <input type="email" name="email" id="email" placeholder="Enter Email Here" required><br><br>
            <label for="pickup_address">Pickup Address: </label>
            <input type="text" name="pickup_address" id="pickup-address" placeholder="Enter Street Address of stall here" required><br><br>
            <label for="state">State: </label>
            <select name="state" id="state">
                <option value="state">State</option>
                <option value="selangor">Selangor</option>
            </select>
            <label for="city">City: </label>
            <select name="city" id="city">
                <option value="city">City</option>
                <option value="ampang">Ampang</option>
                <option value="puchong">Puchong</option>
                <option value="subang-jaya">Subang Jaya</option>
                <option value="cheras">Cheras</option>
                <option value="shah-alam">Shah Alam</option>
            </select><br><br>
            <label for="postal">Postal Code: </label>
            <input type="text" name="postal" id="postal-code" pattern="[0-9]{5}" placeholder="Enter Postal Code Here"><br><br>
            <label for="category">Cuisine type: </label>
            <select name="category" id="category">
                <option value="category" selected disabled>Cuisine type</option>
                <option value="Japanese">Japanese</option>
                <option value="korean">Korean</option>
                <option value="malaysian">Malaysian</option>
                <option value="italian">Italian</option>
                <option value="thai">Thai</option>
                <option value="dessert">dessert</option>
                <option value="drinks">Coffee & Tea</option>
            </select><br><br>
            <label for="profile-pic">Stall image:</label>
            <input type="file" accept=".jpeg" name="file">
            <button type="submit" name="appli-form" style="background-color: tomato;">Finish and Submit</button>
        </form>

     </div>
</body>
</html>
