<?php

session_start();
session_destroy();

echo "<script>alert('User Successfully Logged Out.')</script>";

header("location: mainpage.php")

?>

