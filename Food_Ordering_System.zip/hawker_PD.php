<?php
    include'config.php';
    
    error_reporting(0);

    session_start();

    if(!isset($_SESSION['Uname'])) {
        header("Location: index.php");
    } else {
        $Uname = $_SESSION['Uname'];
    }

    $sql = "SELECT u.*, apli.* FROM user u, application_form apli WHERE u.userID = apli.userID AND u.username = '$Uname' ";
    $db = mysqli_query($conn, $sql);
    while ($result = mysqli_fetch_assoc($db)) {
      $userID = $result['userID'];
      $stallName = $result['stall_name'];
      $sql1 = mysqli_query($conn, "SELECT apli.*, cat.* FROM application_form apli, category cat WHERE apli.categoryID = cat.categoryID AND apli.stall_name = '$stallName' ");
      while ($row = mysqli_fetch_assoc($sql1)){
        $Fullname = $row['full_name'];
        $phone = $row['phone_number'];
        $email = $row['email'];
        $pickAdd = $row['pickup_address'];
        $postal = $row['postal_code'];
        $city = $row['city'];
        $state = $row['state'];
        $category = $row['category_name'];
        $hawk_img = $row['hawk_img'];
      }
    }

    if (isset($_POST['updateInfo'])) {
      $new_name = $_POST['fullname'];
      $new_phone = $_POST['phone'];
      $new_email = $_POST['email'];
      $new_pickAdd = $_POST['address'];
      $new_postal = $_POST['postal'];
      $new_city = $_POST['city'];
      $new_state = $_POST['state'];
      $query = "UPDATE `application_form` SET `full_name`='$new_name',`phone_number`='$new_phone',`email`='$new_email',`pickup_address`='$new_pickAdd',`postal_code`='$new_postal',`city`='$new_city',`state`='$new_state' WHERE stall_name = '$stallName' ";
      $result = mysqli_query($conn, $query);
      echo '<script>alert("Changes Saved!")</script>';
      echo '<script>window.location="hawker_PD.php"</script>';
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Personal Details</title>
  <link rel="stylesheet" href="hawker_PD.css" />
  <script
    src="https://kit.fontawesome.com/a0eb58ef8d.js"
    crossorigin="anonymous"
  ></script>
</head>
<body>
    <!-- universal nav bar -->
    <nav>
      <div class="logo">
      <a href="#"><img src="img/logo.jpeg" alt="logo" /></a>
      </div>
      <li class="logoname">Grubs4Grabs</li>
      <ul>
        <div>
            <li><a href="mod-menu.php">Menu</a></li>
            <li><a href="hawker-order.php">Order</a></li>
            <li><a href="hwk_order_hist.php">Order History</a></li>
            <li><a href="hawker_PD.php">Profile</a></li>
        </div>
        <li id="signout"><a href="logout.php">Sign Out</a></li>
      </ul>
    </nav>

  <!-- Main content -->


    <div class="content">
      <center>
          <div class="circle">
            <img src="<?php echo $hawk_img; ?>" alt="hawker pic">
          </div>
      </center>
      <div class="user-profile">
        <form action="" method="POST">
          <label for="fullname">Full Name: </label><br>
          <input
            type="text"
            name="fullname"
            id="fullname"
            maxlength="50"
            value="<?php echo $Fullname; ?>"
            required
          /><br />
          <label for="phone">Phone Number: </label><br>
          <input
            type="tel"
            name="phone"
            id="phone"
            pattern="[0-9]{11}"
            value="<?php echo $phone; ?>"
          /><br />
          <label for="email">Email: </label><br>
          <input
            type="email"
            name="email"
            id="email"
            pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2, 4}$"
            value="<?php echo $email; ?>"
            required
          /><br />
          <label for="category">Category: </label>
          <input type="text" name="category" id="category" value="<?php echo $category; ?>" readonly /><br />
          <label for="address">Pickup Address: </label>
          <input type="text" name="address" value="<?php echo $pickAdd; ?>" required /><br />
          <label for="postal">Postal Code: </label>
          <input type="number" min="10000" maxlength="99999" name="postal" value="<?php echo $postal; ?>" required /><br />
          <label for="city">City: </label>
          <input type="text" name="city" value="<?php echo $city; ?>" required /><br />
          <label for="state">State: </label>
          <input type="text" name="state" value="<?php echo $state; ?>" required /><br />
          <div class="edit-profile">
              <button type="submit" name="updateInfo">Save Changes</button>
          </div>
        </form>
      </div>
    </div>
  </body>
</html>