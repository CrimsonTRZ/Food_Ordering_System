<?php
    include'config.php';
    
    error_reporting(0);
    
    session_start();

    if(!isset($_SESSION['Uname'])) {
        header("Location: index.php");
    } else {
        $Uname = $_SESSION['Uname'];
    }

    $query = "SELECT u.*, hoh.* FROM user u, hawk_order_hist hoh WHERE u.userID = hoh.userID AND u.username= '$Uname' ";
    $db= mysqli_query($conn, $query);
    while($result=mysqli_fetch_assoc($db)){
        $userID = $result['userID'];
    }

    if (isset($_POST['confirmDate'])) {
        $date = filter_input(INPUT_POST, 'date', FILTER_SANITIZE_STRING);
      } else {
        echo '<script>alert("No date selected. Please select date to view order history.")</script>';
      }

?>
<!DOCTYPE html>
<html>
    <head>
        <title>Order History Hawker</title>
        <link rel="stylesheet" type="text/css" href="hwk_order_hist.css" />
        <script src="https://kit.fontawesome.com/a0eb58ef8d.js" crossorigin="anonymous"></script>
    </head>
    <body>

    <!-- universal nav bar -->
    <nav>
      <div class="logo">
      <a href="#"><img src="img/logo.jpeg" alt="logo" /></a>
      </div>
      <li class="logoname">Grubs4Grabs</li>
      <ul>
        <div>
            <li><a href="mod-menu.php">Menu</a></li>
            <li><a href="hawker-order.php">Order</a></li>
            <li><a href="hwk_order_hist.php">Order History</a></li>
            <li><a href="hawker_PD.php">Profile</a></li>
        </div>
        <li id="signout"><a href="logout.php">Sign Out</a></li>
      </ul>
    </nav>
    <!-- 1st section main content -->
    <div class="content">
        <div class="Date-Selection">
            <div class="heading">
                <h3> Order History</h3>
            </div>
            <!-- select date of purchase to see order history -->
            <form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']) ?>">
            <label for="date" id="date-label">Date:</label>
            <select name="date" id="date">
                <?php
                    $sql = "SELECT * FROM hawk_order_hist WHERE userID = '$userID' ";
                    $db = mysqli_query($conn, $sql);
                    while ($result = mysqli_fetch_array($db)) {
                ?>
                <option value="<?php echo $result['orderDate']; ?>" <?php echo($result['orderDate'] == $date?"selected":""); ?>> 
                    <?php echo $result['orderDate']; ?>
                </option>
                <?php
                    }
                ?>
            </select>
            <button type="submit" name="confirmDate" id="select-date-button">Select Date</button>
            </form>
        </div>
    </div>

    <!-- Order History -->
    <?php
        $sql = "SELECT hoh.*, u.* FROM hawk_order_hist hoh, user u WHERE hoh.userID = u.userID AND hoh.userID = '$userID' AND orderDate = '$date' ";
        $result = mysqli_query($conn, $sql);
        while ($row = mysqli_fetch_array($result)) {
            $orderID = $row['hawkOH_ID'];
    ?>
    <div class="History_selection">
        <button class="collapsible">
            <table>
                <tr>
                    <th>Order ID</th>
                    <th>Total items</th>
                    <th>Subtotal</th>
                </tr>
                <tr>
                    <td><?php echo $row['hawkOH_ID'] ?></td>
                    <td><?php echo $row['total_items'] ?></td>
                    <td>RM <?php echo $row['subtotal'] ?></td>
                </tr>
                
            </table>
        </button>
        
        <div class="Order_History">
            <table>
                <tr>
                    <th>Item</th>
                    <th>Quantity</th>
                    <th>Total Price</th>
                </tr>
                <?php
                    $sql = "SELECT ctl.*, hohd.* FROM catalogue ctl, hawk_order_hist_detail hohd WHERE ctl.foodID = hohd.foodID AND hohd.hawkOH_ID = '$orderID' ";
                    $result = mysqli_query($conn, $sql);
                    if(mysqli_num_rows($result) > 0){
                        while($row= mysqli_fetch_array($result)) {
                ?>
                <tr>
                    <td><?php echo $row['foodName']; ?></td>
                    <td><?php echo $row['quantity']; ?></td>
                    <td>RM <?php echo $row['total']; ?></td>
                </tr>
                <?php
                        }
                    }
                ?>
            </table>
        </div>
        
    </div>
    <?php
        }
    ?>


    <script>
        var coll = document.getElementsByClassName("collapsible");
        var i;
  
        for (i = 0; i < coll.length; i++) {
          coll[i].addEventListener("click", function () {
            this.classList.toggle("active");
            var content = this.nextElementSibling;
            if (content.style.maxHeight) {
              content.style.maxHeight = null;
            } else {
              content.style.maxHeight = content.scrollHeight + "px";
            }
          });
        }
      </script>
        
    </body>
</html>