<?php
  include'config.php';

  error_reporting(0);

  session_start();

  if(isset($_SESSION['Uname'])) {
    if ($_SESSION['User_privilege'] == 'customer'){
      header("Location: mainpage.php");
    } elseif ($_SESSION['User_privilege'] == 'hawker') {
      header("Location: mod-menu.php");
    } elseif ($_SESSION['User_privilege'] == 'admin') {
      header("Location: admin_account.php");
    }
  }
  
  if(isset($_POST['login'])){
    $Uname = mysqli_real_escape_string($conn,$_POST['Uname']);
    $Upassword = md5($_POST['Upassword']);

    $sql = "SELECT * FROM user WHERE username='$Uname' AND password = '$Upassword'";
    $result = mysqli_query($conn, $sql);
    if ($result->num_rows > 0 ) {
      $row = mysqli_fetch_assoc($result);
      $_SESSION['Uname'] = $row['username'];
      $_SESSION['User_privilege'] = $row['privilege'];
      if(isset($_SESSION['Uname'])) {
        if ($_SESSION['User_privilege'] == 'customer'){
          header("Location: mainpage.php");
        } elseif ($_SESSION['User_privilege'] == 'hawker') {
          header("Location: mod-menu.php");
        } elseif ($_SESSION['User_privilege'] == 'admin') {
          header("Location: admin_account.php");
        }
      }
    } else {
      echo "<script>alert('Username or Password is Invalid.')</script>";
    }
  }

  // Search function (search by category and stall name)
  if (isset($_POST['lookup'])) {
    $search = mysqli_real_escape_string($conn, $_POST['search']);
    $query = mysqli_query($conn, "SELECT * FROM category WHERE category_name  LIKE '%$search%' ");
    $result = mysqli_num_rows($query);
    if ($result > 0) {
        while($row = mysqli_fetch_assoc($query)){
            $ctgID = $row['categoryID'];
            if ($ctgID) {
                echo '<script>window.location="Category.php?categoryID='.$ctgID.'"</script>';
            }
        }
    }
    $query1 = mysqli_query($conn, "SELECT * FROM application_form WHERE stall_name LIKE '%$search%' ");
    $result1 = mysqli_num_rows($query1);
    if ($result1 > 0) {
        while($row = mysqli_fetch_assoc($query1)){
            $stallName = $row['stall_name'];
            if ($stallName) {
                echo '<script>window.location="hawker-menu.php?stall_name='.$stallName.'"</script>';
            }
        }
    } else {
        echo "<script>alert('Search result not found. Please try another keyword.')</script>";
    }
  }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Index Page</title>
    <link rel="stylesheet" href="loginregister.css" />
    <script src="https://kit.fontawesome.com/a0eb58ef8d.js" crossorigin="anonymous"></script>
</head>
<body>

<!-- universal nav bar -->
  <nav>
    <div class="logo">
      <a href="#"><img src="img/logo.jpeg" alt="logo" /></a>
    </div>
    <li class="logoname">Grubs4Grabs</li>
    <ul>
      <div>
        <li><a href="mainpage.php">Home Page</a></li>
        <li><a href="personal-details.php">Profile</a></li>
        <li><a href="cart.php">Cart</a></li>
        <li><a href="join-family.php">Join Our Family</a></li>
        <li><a href="register.php">Sign Up</a></li>
        <li><a href="index.php">Login</a></li>
        <li><a href="logout.php">Sign Out</a></li>
      </div>
      <form action="" class="searchbar" method="post">
        <input type="search" placeholder="Search.." name="search" />
        <button type="submit" name="lookup">
          <i class="fas fa-search"></i>
        </button>
      </form>
    </ul>
  </nav>

<!-- login -->

  <!-- <div class="container">
      <div class="forms-container">
        <div class="login-register">
          <form action="" method="post" class="login-form">
            <center><h2 class="title"><u>Login</u></h2></center>
            <div class="input-field">
              <input type="text" placeholder="Username" name="Uname" value="<?php echo $_POST['Uname']; ?>" required />
            </div>
            <div class="input-field">
              <input type="password" placeholder="Password" name="Upassword" value="<?php echo $_POST['Upassword']; ?>" required />
            </div>
            <div class="input-field">
              <button type = "submit" class= "login" name="login">Login</button>
            </div>
            <center><p class = "login-fail">New here? <a href="register.php" style="color: #4590ef;">Register Here.</a></p></center>
          </form>
        </div>
      </div>
  </div> -->

  <div class="container">
        <div class="forms-container">
          <div class="login-register">
            <form action="" method="post" class="login-form">
              <center><h2 class="title"><u>Login</u></h2></center>
              <div class="input-field">
                <input type="text" placeholder="Username" name="Uname" value="<?php echo $_POST['Uname']; ?>" required />
              </div>
              <div class="input-field">
                <input type="password" placeholder="Password" name="Upassword" value="<?php echo $_POST['Upassword']; ?>" required />
              </div>
              <div class="input-field">
                <button type = "submit" class= "login" name="login">Login</button>
              </div>
              <center><p class = "login-fail">New here? <a href="register.php" style="color: #340267; font-weight: bold">Register Here.</a></p></center>
            </form>
        </div>
      </div>
  </div>
</body>
</html>