<?php
    include'config.php';
    
    error_reporting(0);

    session_start();

    if(!isset($_SESSION['Uname'])) {
        header("Location: index.php");
    } else {
        $Uname = $_SESSION['Uname'];
    }

  // Search function (search by category and stall name)
    if (isset($_POST['lookup'])) {
      $search = mysqli_real_escape_string($conn, $_POST['search']);
      $query = mysqli_query($conn, "SELECT * FROM category WHERE category_name  LIKE '%$search%' ");
      $result = mysqli_num_rows($query);
      if ($result > 0) {
          while($row = mysqli_fetch_assoc($query)){
              $ctgID = $row['categoryID'];
              if ($ctgID) {
                  echo '<script>window.location="Category.php?categoryID='.$ctgID.'"</script>';
              }
          }
      }
      $query1 = mysqli_query($conn, "SELECT * FROM application_form WHERE stall_name LIKE '%$search%' ");
      $result1 = mysqli_num_rows($query1);
      if ($result1 > 0) {
          while($row = mysqli_fetch_assoc($query1)){
              $stallName = $row['stall_name'];
              if ($stallName) {
                  echo '<script>window.location="hawker-menu.php?stall_name='.$stallName.'"</script>';
              }
          }
      } else {
          echo "<script>alert('Search result not found. Please try another keyword.')</script>";
      }
    }

    if (isset($_POST['confirm-payment'])) {
      echo "<script>alert('Payment Successful! Thank You for your Patrionage!')</script>";
      echo '<script>window.location="cus_order_hist.php"</script>';
    }

?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Payment Methods</title>
    <link rel="stylesheet" type="text/css" href="payment-methods.css" />
    <script
      src="https://kit.fontawesome.com/a0eb58ef8d.js"
      crossorigin="anonymous"
    ></script>
  </head>
  <body>
    <!-- universal nav bar -->
    <nav>
        <div class="logo">
          <a href="#"><img src="img/logo.jpeg" alt="logo" /></a>
        </div>
        <li class="logoname">Grubs4Grabs</li>
        <ul>
          <div>
            <li><a href="mainpage.php">Home Page</a></li>
            <li><a href="personal-details.php">Profile</a></li>
            <li><a href="cart.php">Cart</a></li>
            <li><a href="join-family.php">Join Our Family</a></li>
            <li><a href="register.php">Sign Up</a></li>
            <li><a href="index.php">Login</a></li>
            <li><a href="logout.php">Sign Out</a></li>
          </div>
          <form action="" class="searchbar" method="post">
            <input type="search" placeholder="Search.." name="search" />
            <button type="submit" name="lookup">
              <i class="fas fa-search"></i>
            </button>
          </form>
        </ul>
    </nav>

    <!-- Logout modal -->
    <div class="modal" id="logout">
      <div class="modal-content">
        <div class="modal-header">
          SIGN OUT
          <button class="icon modal-close">
            <i class="fas fa-times"></i>
          </button>
        </div>
      <div class="modal-body">Do you wish to sign out?</div>
        <div class="modal-footer">
          <button class="link modal-close">No</button>
          <button class="confirm">Yes</button>
        </div>
      </div>
    </div>

    <!-- universal side nav -->
    <div class="circle-box">
        <center>
            <div class="circle">
                <img src="img/avatar.jpg" alt="profile picture" />
            </div>
        </center>
    </div>
    <div class="sidenav">
        <ul>
            <li><a href="cart.php">My Cart</a></li>
            <li><a href="cus_order_hist.php">Order History</a></li>
            <li><a href="personal-details.php">Personal Details</a></li>
            <li>
                <a class="modal-open" data-modal="logout" id="signout">Sign Out</a>
            </li>
        </ul>
    </div>

    <div class="content">
      <!-- card detail validation done using javascript -->
      <div class="payment-method1">
        <h3>Credit/Debit Card:</h3>
        <div class="card-detail">
          <form action="#" method="post">
            <label for="cardowner">Full name of Card Owner: </label>
            <input type="text" name="cardowner" id="cardowner" /><br />
            <label for="cardtype">Card Type(Visa/MasterCard): </label>
            <select name="cardtype" id="cardtype">
              <option value="cardtype" selected disabled>Card Type</option>
              <option value="visacard">Visa Card</option>
              <option value="mastercard">MasterCard</option></select
            ><br />
            <label for="cardnumber">Card Number: </label>
            <input
              type="text"
              name="cardnumber"
              id="cardnumber"
              required
              pattern="[0-9]{16}"
            />
            <br />
            <label for="expirydate">Expiry Date: </label>
            <select name="expirymonth" id="expirymonth">
              <option value="month" selected disabled>mm</option>
              <option value="01">01</option>
              <option value="02">02</option>
              <option value="03">03</option>
              <option value="04">04</option>
              <option value="05">05</option>
              <option value="06">06</option>
              <option value="07">07</option>
              <option value="08">08</option>
              <option value="09">09</option>
              <option value="10">10</option>
              <option value="11">11</option>
              <option value="12">12</option>
            </select>
            <select name="expiryyear" id="expiryyear" placeholder>
              <option value="year" selected disabled>yy</option>
              <option value="2021">2021</option>
              <option value="2022">2022</option>
              <option value="2023">2023</option>
              <option value="2024">2024</option>
              <option value="2025">2025</option>
              <option value="2026">2026</option>
              <option value="2027">2027</option>
              <option value="2028">2028</option>
              <option value="2029">2029</option>
              <option value="2030">2030</option>
              <option value="2031">2031</option>
              <option value="2032">2032</option>
              <option value="2033">2033</option>
              <option value="2034">2034</option>
              <option value="2035">2035</option>
              <option value="2036">2036</option>
              <option value="2037">2037</option>
              <option value="2038">2038</option>
              <option value="2039">2039</option>
              <option value="2040">2040</option></select
            ><br />
            <label for="cvv: ">CVV: </label>
            <input
              type="text"
              name="cvv"
              id="cvv"
              pattern="[0-9]{3}"
              required
            /><br /><br />
            <div class="make-payment">
              <button
                type="submit"
                name="confirm-payment"
                class="modal-open"
                data-modal="modal1"
              >
                Confirm
              </button>
            </div>
          </form>
        </div>
      </div>
      <hr />
      <!-- bank detail validation done using javascript -->
      <div class="payment-method2">
        <h3>Online Banking:</h3>
        <div class="bank-detail">
          <form action="#" method="post">
            <label for="bankowner">Full Name of Bank Account: </label>
            <input type="text" name="bankowner" id="bankowner" /><br />
            <label for="bankname">Bank Name: </label>
            <select name="bankname" id="bankname">
              <option value="bankname" selected disabled>Bank Name</option>
              <option value="maybank">Maybank</option>
              <option value="bankislam">Bank Islam</option>
              <option value="cimbbank">CIMB Bank</option>
              <option value="publicbank">Public Bank</option></select
            ><br />
            <label for="bankaccountnumber">Account Number: </label>
            <input
              type="text"
              name="bankaccountnumber"
              id="bankaccountnumber"
            /><br /><br />
            <div class="make-payment">
              <button
                type="submit"
                name="confirm-payment"
                class="modal-open"
                data-modal="modal1"
              >
                Confirm
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </body>
</html>

<script>
      var modalBtns = document.querySelectorAll(".modal-open");

      modalBtns.forEach(function (btn) {
        btn.onclick = function () {
          var modal = btn.getAttribute("data-modal");

          document.getElementById(modal).style.display = "block";
        };
      });

      var closeBtns = document.querySelectorAll(".modal-close");

      closeBtns.forEach(function (btn) {
        btn.onclick = function () {
          var modal = (btn.closest(".modal").style.display = "none");
        };
      });
</script>

<script>
  var logoutBtn = document.querySelectorAll(".confirm");

  logoutBtn.forEach(function (btn) {
    btn.onclick = function () {
      window.location = "logout.php"
    };
  });
</script>