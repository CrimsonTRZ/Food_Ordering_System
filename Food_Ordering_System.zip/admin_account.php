<?php
    include'config.php';
    
    error_reporting(0);

    session_start();

    if(!isset($_SESSION['Uname'])) {
        header("Location: index.php");
    } else {
        $Uname = $_SESSION['Uname'];
    }

    // Declare empty variables password & user privilege
    $password = "";
    $privilege = "";

    // Search function (search by category and stall name)
    if (isset($_POST['lookup'])) {
        $search = mysqli_real_escape_string($conn, $_POST['search']);
        $query = mysqli_query($conn, "SELECT * FROM user WHERE username LIKE '%$search%' ");
        $result = mysqli_num_rows($query);
        if ($result > 0) {
            while($row = mysqli_fetch_assoc($query)){
                $userID = $row['userID'];
                if ($userID) {
                    echo '<script>window.location="admin_account.php?search=true&userID='.$userID.'"</script>';
                } else {
                    echo '<script>alert("Username not found. Retry.")</script>';
                }
            }
        }
    }

    // select action to either edit or delete account
    if ($_GET['action'] == "edit") {
        $userID = $_GET['userID'];
        $query = mysqli_query($conn, "SELECT * FROM user WHERE userID = '$userID' ");
        if (mysqli_num_rows($query) > 0 ) {
            while($result = mysqli_fetch_array($query)){
                $password = $result['password'];
                $privilege = $result['privilege'];
            }
        }
    } elseif ($_GET['action'] == "remove") {
        $userID = $_GET['userID'];
        $query = "DELETE FROM `user` WHERE `user`.`userID` = $userID ";
        $result = mysqli_query($conn, $query);
        echo '<script>alert("User account deleted!")</script>';
        header('location: admin_account.php');
    }

    if (isset($_POST['update'])) {
        $targetUid = $_POST['target_userID'];
        $password = md5($_POST['password']);
        $privilege = $_POST['privilege'];

        $query = mysqli_query($conn, "UPDATE user SET password = '$password', privilege = '$privilege' WHERE userID = '$targetUid' ");
        echo '<script>alert("User information has been updated!")</script>';
        header('location: admin_account.php');
    }

?>

<!DOCTYPE html>
<html>
    <head>
        <title>Admin Account</title>
        <link rel="stylesheet" type="text/css" href="admin_account.css" />
        <script src="https://kit.fontawesome.com/a0eb58ef8d.js" crossorigin="anonymous"></script>
    </head>
    <body>
        <!-- universal nav bar -->
    <nav>
        <div class="logo">
        <a href="#"><img src="img/logo.jpeg" alt="logo" /></a>
        </div>
        <li class="logoname">Grubs4Grabs</li>
        <ul>
        <div>
            <li><a href="admin_account.php">Accounts</a></li>
            <li><a href="admin_PD.php">User Profile</a></li>
        </div>
        <li id="signout"><a href="logout.php">Sign Out</a></li>
        </ul>
    </nav>
        <!-- Table -->
		<div class="search-section">
		  <center>
			<form action="" class="searchbar" method="post">
			  <input
				type="search"
				placeholder="Search for Account Name Here"
				name="search"
			  />
			  <button type="submit" name="lookup">
				<i class="fas fa-search"></i>
			  </button>
			</form>
		  </center>
		</div>

		<div class="account-table">
		  <center>
			<table>
			  <tr>
                <th>userID</th>
                <th>username</th>
                <th>Password</th>
                <th>Contact Number</th>
                <th>Email Address</th>
                <th>Home Address</th>
                <th>D.O.B</th>
                <th>User Privilege</th>
                <th colspan="2">Action</th>
            </tr>
            <div>
                <?php
                    if (!$_GET['search'] == "true"){
                        $sql = "SELECT * FROM user";
                        $db = mysqli_query($conn, $sql);
                        while ($result = mysqli_fetch_array($db)) {
                ?>
                    <tr>
                        <td><?php echo $result['userID']; ?> </td>
                        <td><?php echo $result['username']; ?></td>
                        <td><?php echo $result['password']; ?></td>
                        <td><?php echo $result['phone_number']; ?></td>
                        <td><?php echo $result['email_address']; ?></td>
                        <td><?php echo $result['street_address'] . ", " . $result['postal_code'] . " " . $result['city'] . ", " . $result['state']; ?></td>
                        <td><?php echo $result['Date_of_Birth']; ?></td>
                        <td><?php echo $result['privilege']; ?></td>
                        <td><a href="admin_account.php?action=edit&userID=<?php echo $result["userID"]; ?>"><i class="fas fa-edit"></i></a></td>
                        <td><a href="admin_account.php?action=remove&userID=<?php echo $result["userID"]; ?>"><i class="fas fa-user-slash"></i></a></td>
                    </tr>
                <?php
                        }
                    } elseif ($_GET['search'] == "true"){
                        $userID = $_GET['userID'];
                        $sql = "SELECT * FROM user WHERE userID = $userID ";
                        $db = mysqli_query($conn, $sql);
                        while ($result = mysqli_fetch_array($db)) {
                ?>
                    <tr>
                        <td><?php echo $result['userID']; ?> </td>
                        <td><?php echo $result['username']; ?></td>
                        <td><?php echo $result['password']; ?></td>
                        <td><?php echo $result['phone_number']; ?></td>     
                        <td><?php echo $result['email_address']; ?></td>
                        <td><?php echo $result['street_address'] . ", " . $result['postal_code'] . " " . $result['city'] . ", " . $result['state']; ?></td>
                        <td><?php echo $result['Date_of_Birth']; ?></td>
                        <td><?php echo $result['privilege']; ?></td>
                        <td><a href="admin_account.php?action=edit&userID=<?php echo $result["userID"]; ?>"><i class="fas fa-edit"></i></a></td>
                        <td><a href="admin_account.php?action=remove&userID=<?php echo $result["userID"]; ?>"><i class="fas fa-user-slash"></i></a></td>
                    </tr>
                <?php
                    }
                }
                ?>
            </div>
        </table>

        <div class="update-account">
            <form action="" method="post">
                <input type="hidden" name="target_userID" value="<?php echo $userID; ?>">
                <div class="new-password">
                    <label for="password">Password</label><br>
                    <input type="text" name="password" value="<?php echo $password; ?>" placeholder="Enter new password here.">
                </div>
                <div class="new-privilege">
                    <label for="privilege">User Privilege</label><br>
                    <input type="text" name="privilege" value="<?php echo $privilege; ?>" placeholder="Enter user privilege here.">
                </div>
                <button class="update-account" type="submit" name="update">Save Changes</button>
            </form>
        </div>
    </body>
</html>