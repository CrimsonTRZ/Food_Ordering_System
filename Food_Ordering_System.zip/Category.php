<?php
  include'config.php';

  error_reporting(0);

  session_start();

  if(!isset($_SESSION['Uname'])) {
    header("Location: index.php");
  }

//   pass category ID from mainpage
  if (isset($_GET['categoryID'])) {
      $categoryID = $_GET['categoryID'];
  }

  // Search function (search by category and stall name)
  if (isset($_POST['lookup'])) {
    $search = mysqli_real_escape_string($conn, $_POST['search']);
    $query = mysqli_query($conn, "SELECT * FROM category WHERE category_name  LIKE '%$search%' ");
    $result = mysqli_num_rows($query);
    if ($result > 0) {
        while($row = mysqli_fetch_assoc($query)){
            $ctgID = $row['categoryID'];
            if ($ctgID) {
                echo '<script>window.location="Category.php?categoryID='.$ctgID.'"</script>';
            }
        }
    }
    $query1 = mysqli_query($conn, "SELECT * FROM application_form WHERE stall_name LIKE '%$search%' ");
    $result1 = mysqli_num_rows($query1);
    if ($result1 > 0) {
        while($row = mysqli_fetch_assoc($query1)){
            $stallName = $row['stall_name'];
            if ($stallName) {
                echo '<script>window.location="hawker-menu.php?stall_name='.$stallName.'"</script>';
            }
        }
    } else {
        echo "<script>alert('Search result not found. Please try another keyword.')</script>";
    }
  }

  $query = "SELECT a.* , c.* FROM application_form a, category c WHERE a.categoryID = c.categoryID AND c.categoryID = '$categoryID' ";
  $db= mysqli_query($conn, $query);
  while($result=mysqli_fetch_assoc($db)){
      $category_name = $result['category_name'];
      $category_detail = $result['category_detail'];
      $img = $result['img'];
      $stallName = $result['stall_name'];
      $stall_img = $result['hawk_img'];
  }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Category Page</title>
    <link rel="stylesheet" href="Category.css" />
    <script src="https://kit.fontawesome.com/a0eb58ef8d.js" crossorigin="anonymous"></script>
</head>
<body>

<!-- universal nav bar -->
  <nav>
        <div class="logo">
          <a href="#"><img src="img/logo.jpeg" alt="logo" /></a>
        </div>
        <li class="logoname">Grubs4Grabs</li>
        <ul>
          <div>
            <li><a href="mainpage.php">Home Page</a></li>
            <li><a href="personal-details.php">Profile</a></li>
            <li><a href="cart.php">Cart</a></li>
            <li><a href="join-family.php">Join Our Family</a></li>
            <li><a href="register.php">Sign Up</a></li>
            <li><a href="index.php">Login</a></li>
            <li><a href="logout.php">Sign Out</a></li>
          </div>
          <form action="" class="searchbar" method="post">
            <input type="search" placeholder="Search.." name="search" />
            <button type="submit" name="lookup">
              <i class="fas fa-search"></i>
            </button>
          </form>
        </ul>
    </nav>

<!-- category content (hawkers img and name) -->
    <div class="circle">
        <?php echo '<img src="data:image/jpeg;base64,'.base64_encode($img).'"alt= "catImg" style="border-radius: 50%;" >' ?>
    </div>
    <div class="content">
        <p class= "Ctname" >Category Name: <?php echo $category_name; ?></p>
        <p class= "Ctdetail" >Category Detail: <?php echo $category_detail; ?></p>
    </div>
    <div class="display_hawkers">
        <div class="hawker">
          <div class="hawker-img">
            <img src="<?php echo $stall_img; ?>" alt="stall pic">
          </div>

          <div class="hawker-name">
            <center>
            <!-- <li class="hawker-name"><?php echo $stallName; ?></li> -->
            <?php echo "<p>". '<a href="hawker-menu.php?stall_name=' . $stallName . '">' . $stallName . "</a>" . "</p>"; ?>
            </center>
          </div>
        </div>
    </div>
    
<!-- previous & next button -->
    <!-- <div class="btn-section">
      <center>
        <button class="btn" onclick="prev()">
          <i class="far fa-arrow-alt-circle-left" id="left-btn"></i>
        </button>
        <button class="btn" onclick="next()">
          <i class="far fa-arrow-alt-circle-right" id="right-btn"></i>
        </button>
      </center>
    </div> -->

</body>
</html>