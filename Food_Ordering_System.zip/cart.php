<?php
    include'config.php';
    
    error_reporting(0);
    
    session_start();

    if (isset( $_SESSION['stallName'])) {
        $stallName = $_SESSION['stallName'];
    }

    if(!isset($_SESSION['Uname'])) {
        header("Location: index.php");
    } else {
        $Uname = $_SESSION['Uname'];
    }

    // Search function (search by category and stall name)
    if (isset($_POST['lookup'])) {
        $search = mysqli_real_escape_string($conn, $_POST['search']);
        $query = mysqli_query($conn, "SELECT * FROM category WHERE category_name  LIKE '%$search%' ");
        $result = mysqli_num_rows($query);
        if ($result > 0) {
            while($row = mysqli_fetch_assoc($query)){
                $ctgID = $row['categoryID'];
                if ($ctgID) {
                    echo '<script>window.location="Category.php?categoryID='.$ctgID.'"</script>';
                }
            }
        }
        $query1 = mysqli_query($conn, "SELECT * FROM application_form WHERE stall_name LIKE '%$search%' ");
        $result1 = mysqli_num_rows($query1);
        if ($result1 > 0) {
            while($row = mysqli_fetch_assoc($query1)){
                $stallName = $row['stall_name'];
                if ($stallName) {
                    echo '<script>window.location="hawker-menu.php?stall_name='.$stallName.'"</script>';
                }
            }
        } else {
            echo "<script>alert('Search result not found. Please try another keyword.')</script>";
        }
    }

    $query = "SELECT u.*, c.* FROM user u, cart c WHERE u.userID = c.userID AND u.username= '$Uname'";
    $db= mysqli_query($conn, $query);
    while($result=mysqli_fetch_assoc($db)){
        $userID = $result['userID'];
        $location = $result['street_address'] . ", " . $result['postal_code'] . " " . $result['city'] . ", " . $result['state'];
        $cartID = $result['cartID'];
        $subtotal = $result['subtotal'];
    }


    //Remove food from cart. 
    if(isset($_GET["action"])){
        if($_GET["action"] == "remove"){
            $foodID = $_GET["foodID"];
            $subtotal = 0;
            $query = "DELETE FROM cart_details WHERE foodID ='$foodID'";
            $result = mysqli_query($conn, $query);
            $query1 = "SELECT * FROM cart_details WHERE cartID = '$cartID' ";
            $db1 = mysqli_query($conn, $query1);
            while($result = mysqli_fetch_assoc($db1)) {
                $total = $result['total'];
                $subtotal = $subtotal + $total;
            }
            $query2 = "UPDATE cart SET subtotal = '$subtotal' WHERE userID = '$userID' ";
            $db2 = mysqli_query($conn, $query2);
            echo '<script>alert("Item Removed from Cart")</script>';
            echo '<script>window.location="cart.php"</script>';
        }
    }
        
    // Insert all food into order history & remove from cart.
    if (isset($_POST['order'])) {
        $query = mysqli_query($conn, "SELECT COUNT(foodID) AS total_items FROM cart_details WHERE cartID = '$cartID' ");
        while ($data = mysqli_fetch_assoc($query)) {
            $total_items = $data['total_items'];
        }
        $query = "INSERT INTO cus_order_hist (`userID`, `total_items`, `subtotal`) VALUES ('$userID', ' $total_items', '$subtotal')";
        $db = mysqli_query($conn, $query);
        
        $sql = "SELECT * FROM cus_order_hist WHERE userID = '$userID' ";
        $db = mysqli_query($conn, $sql);
        while ($result = mysqli_fetch_assoc($db)) {
            $orderID = $result['orderID'];
            }
        
        $query = "SELECT c.*, cd.* FROM cart c, cart_details cd WHERE c.cartID = cd.cartID AND cd.cartID = '$cartID' ";
        $db = mysqli_query($conn, $query);   
        if(mysqli_num_rows($db) > 0){
            while($row= mysqli_fetch_array($db)) {
                $foodID = $row['foodID'];
                $quantity = $row['quantity'];
                $total = $row['total'];
                $query1 = "INSERT INTO cus_order_detail ( `orderID`, `foodID`, `quantity`, `total`)
                           VALUES ('$orderID', '$foodID', '$quantity', '$total') "; 
                $db1 = mysqli_query($conn, $query1);
            }    
        }
        // insert into hawk order list table
        $sql = mysqli_query($conn, "SELECT * FROM catalogue WHERE stall_name = '$stallName' ");
        while ($result = mysqli_fetch_assoc($sql)) {
            $hwk_userID = $result['userID'];
        } 

        $query = "INSERT INTO hawk_order_list(userID, subtotal) VALUES('$hwk_userID' , '$subtotal') ";
        $result = mysqli_query($conn, $query);
        $sql1 = mysqli_query($conn, "SELECT * FROM hawk_order_list WHERE userID = '$hwk_userID' ");
        while ($result = mysqli_fetch_assoc($sql1)) {
            $hawkOR_ID = $result['hawkOR_ID'];
        }
        $query1 = "SELECT c.*, cd.* FROM cart c, cart_details cd WHERE c.cartID = cd.cartID AND cd.cartID = '$cartID' ";
        $db1 = mysqli_query($conn, $query1);   
        if(mysqli_num_rows($db1) > 0){
            while($row = mysqli_fetch_array($db1)) {
                $foodID = $row['foodID'];
                $quantity = $row['quantity'];
                $total = $row['total'];
                $query2 = mysqli_query($conn, "INSERT INTO hawk_order_detail ( `hawkOR_ID`, `foodID`, `quantity`, `total`)
                VALUES ('$hawkOR_ID', '$foodID', '$quantity', '$total') "); 
            }
        }

        // delete from cart
        $query = "DELETE FROM cart_details WHERE cartID = $cartID";
        $db = mysqli_query($conn, $query);
        $query1 = "UPDATE cart SET subtotal = Null WHERE userID = '$userID' ";
        $db1 = mysqli_query($conn, $query1);
        echo '<script>alert("Proceed to Payment to confirm order.")</script>';
        echo '<script>window.location="payment-methods.php"</script>';
    }
    
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cart</title>
    <script src="https://kit.fontawesome.com/a0eb58ef8d.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="cart.css" />
</head>
<body>
    
<!-- universal nav bar -->
    <nav>
        <div class="logo">
            <a href="#"><img src="img/logo.jpeg" alt="logo" /></a>
        </div>
        <li class="logoname">Grubs4Grabs</li>
        <ul>
            <div>
            <li><a href="mainpage.php">Home Page</a></li>
            <li><a href="personal-details.php">Profile</a></li>
            <li><a href="cart.php">Cart</a></li>
            <li><a href="join-family.php">Join Our Family</a></li>
            <li><a href="register.php">Sign Up</a></li>
            <li><a href="index.php">Login</a></li>
            <li><a href="logout.php">Sign Out</a></li>
            </div>
            <form action="" class="searchbar" method="post">
            <input type="search" placeholder="Search.." name="search" />
            <button type="submit" name="lookup">
                <i class="fas fa-search"></i>
            </button>
            </form>
        </ul>
    </nav>

    <!-- Logout modal -->
    <div class="modal" id="logout">
      <div class="modal-content">
        <div class="modal-header">
          SIGN OUT
          <button class="icon modal-close">
            <i class="fas fa-times"></i>
          </button>
        </div>
      <div class="modal-body">Do you wish to sign out?</div>
        <div class="modal-footer">
          <button class="link modal-close">No</button>
          <button class="confirm">Yes</button>
        </div>
      </div>
    </div>

<!-- sidebar -->
    <div class="circle-box">
        <center>
            <div class="circle">
                <img src="img/avatar.jpg" alt="profile picture" />
            </div>
        </center>
    </div>
    <div class="sidenav">
        <ul>
            <li><a href="cart.php">My Cart</a></li>
            <li><a href="cus_order_hist.php">Order History</a></li>
            <li><a href="personal-details.php">Personal Details</a></li>
            <li>
                <a class="modal-open" data-modal="logout" id="signout">Sign Out</a>
            </li>
        </ul>
    </div>

<!-- Main content -->
    <div class="content">
        <div class="Hkname-section">
            <p class= "Hkname" ><h3>Ordering From: <br><?php echo $stallName; ?></h3></p>
        </div>

        <div class="CusLocation-section">
            <p class= "CusLocation" ><h3>Delivering To: <br><?php echo $location; ?></h3></p>
        </div>
        <div class="order-sum">
            <table>
                <tr>
                    <th>Orders</th>
                    <th>Quantity</th>
                    <th>Price</th>
                    <th>Total</th>
                    <th>Action</th>
                </tr>
                
                <?php
                    $sql = "SELECT ctl.*, cd.* FROM catalogue ctl, cart_details cd WHERE ctl.foodID = cd.foodID AND cd.cartID = '$cartID' ";
                    $result = mysqli_query($conn, $sql);
                    if(mysqli_num_rows($result) > 0){
                        while($row= mysqli_fetch_array($result)) {
                ?>
                <tr>
                    <td><?php echo $row["foodName"]; ?></td>
                    <td><?php echo $row["quantity"]; ?></td>
                    <td>RM <?php echo $row["foodPrice"]; ?></td>
                    <td>RM <?php echo number_format($row['total'], 2);?></td>
                    <td><a href="cart.php?action=remove&foodID=<?php echo $row["foodID"]; ?>"><span class="text-danger">Remove</span></a></td>
                </tr>
                <?php
                        }
                ?>
                <tr>
                    <td colspan="3" id="subtotal">Subtotal</td>
                    <td>RM <?php echo number_format($subtotal, 2); ?></td>
                    <td></td>
                </tr>
                <?php
                    }
                ?>   
            </table>
        </div>
        <div class="place-order">
            <form action="" method="post">
                <button type="submit" name="order">Place Order</button>
            </form>
        </div>
    </div>

</body>
</html>

<script>
      var modalBtns = document.querySelectorAll(".modal-open");

      modalBtns.forEach(function (btn) {
        btn.onclick = function () {
          var modal = btn.getAttribute("data-modal");

          document.getElementById(modal).style.display = "block";
        };
      });

      var closeBtns = document.querySelectorAll(".modal-close");

      closeBtns.forEach(function (btn) {
        btn.onclick = function () {
          var modal = (btn.closest(".modal").style.display = "none");
        };
      });
</script>

<script>
  var logoutBtn = document.querySelectorAll(".confirm");

  logoutBtn.forEach(function (btn) {
    btn.onclick = function () {
      window.location = "logout.php"
    };
  });
</script>