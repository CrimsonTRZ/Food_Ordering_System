<?php
    include'config.php';
    
    error_reporting(0);

    session_start();

    if(!isset($_SESSION['Uname'])) {
        header("Location: index.php");
    } else {
        $Uname = $_SESSION['Uname'];
    }

//   pass stall_name from mainpage
    if (isset($_GET['stall_name'])) {
        $stallName = $_GET['stall_name'];
        $_SESSION['stallName'] = $stallName;
    }

    // Search function (search by category and stall name)
    if (isset($_POST['lookup'])) {
        $search = mysqli_real_escape_string($conn, $_POST['search']);
        $query = mysqli_query($conn, "SELECT * FROM category WHERE category_name  LIKE '%$search%' ");
        $result = mysqli_num_rows($query);
        if ($result > 0) {
            while($row = mysqli_fetch_assoc($query)){
                $ctgID = $row['categoryID'];
                if ($ctgID) {
                    echo '<script>window.location="Category.php?categoryID='.$ctgID.'"</script>';
                }
            }
        }
        $query1 = mysqli_query($conn, "SELECT * FROM application_form WHERE stall_name LIKE '%$search%' ");
        $result1 = mysqli_num_rows($query1);
        if ($result1 > 0) {
            while($row = mysqli_fetch_assoc($query1)){
                $stallName = $row['stall_name'];
                if ($stallName) {
                    echo '<script>window.location="hawker-menu.php?stall_name='.$stallName.'"</script>';
                }
            }
        } else {
            echo "<script>alert('Search result not found. Please try another keyword.')</script>";
        }
    }

    $query = "SELECT a.* , c.* FROM application_form a, catalogue c WHERE a.stall_name = c.stall_name AND c.stall_name = '$stallName' ";
    $db= mysqli_query($conn, $query);
    while($result=mysqli_fetch_assoc($db)){
        $stall_img = $result['hawk_img'];
        $location = $result['pickup_address'] . ", " . $result['postal_code'] . " " . $result['city'] . ", " . $result['state'];
        $stall_name = $result['stall_name']; 
    }

    $query1 = "SELECT u.*, c.* FROM user u, cart c WHERE u.userID = c.userID AND u.username= '$Uname'";
    $db1 = mysqli_query($conn, $query1);
    while($result=mysqli_fetch_assoc($db1)){
        $cartID = $result['cartID'];
        $userID = $result['userID'];
    }
    
    // add selected food into cart
    if(isset($_POST['cart'])){
        $quantity = $_POST["quantity"];
        $foodID = $_GET["foodID"];
        $foodPrice = $_POST["hidden_foodPrice"];
        $total = $quantity * $foodPrice;
        $subtotal = 0;
        $sql = mysqli_query($conn, "SELECT * FROM cart_details WHERE cartID = '$cartID' ");
        while ($result = mysqli_fetch_array($sql)) {
            $foodExists = $result['foodID'];
        }
        echo $foodExists;
        if ($foodExists == $foodID) {
            echo "<script>alert('Food item already exists in cart.')</script>";
        } else {

            $query = "INSERT INTO cart_details (`cartID`, `foodID`, `quantity`, `total`) 
                    VALUES ('$cartID', '$foodID', '$quantity', '$total')";
            $db= mysqli_query($conn, $query);
            $query1 = "SELECT * FROM cart_details WHERE cartID = '$cartID' ";
            $db1 = mysqli_query($conn, $query1);
            while($result = mysqli_fetch_assoc($db1)) {
                $total = $result['total'];
                $subtotal = $subtotal + $total;
            }
            $query2 = "UPDATE cart SET subtotal = '$subtotal' WHERE userID = '$userID' ";
            $db2 = mysqli_query($conn, $query2);
            echo '<script>alert("Food added to cart.")</script>';
        }
    }
      
  
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hawker Stall - menu page</title>
    <script src="https://kit.fontawesome.com/a0eb58ef8d.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="hawker-menu.css">
</head>
<body>

<!-- universal nav bar -->
    <nav>
        <div class="logo">
            <a href="#"><img src="../Assignment/img/logo.jpeg" alt="logo" /></a>
        </div>
        <li class="logoname">Grubs4Grabs</li>
        <ul>
            <div>
                <li><a href="mainpage.php">Home Page</a></li>
                <li><a href="personal-details.php">Profile</a></li>
                <li><a href="cart.php">Cart</a></li>
                <li><a href="join-family.php">Join Our Family</a></li>
                <li><a href="register.php">Sign Up</a></li>
                <li><a href="index.php">Login</a></li>
                <li><a href="logout.php">Sign Out</a></li>
            </div>
            <form action="" class="searchbar" method="post">
                <input type="search" placeholder="Search.." name="search">
                <button type="submit" name="search"><i class="fas fa-search"></i></button>
            </form>
        </ul>
    </nav>
    
<!-- category content (hawkers img and name) -->
    <div class="circle">
        <img src="<?php echo $stall_img; ?>" alt="stall pic">
        <!-- style="border-radius: 50%;" -->
    </div>
    <div class="content">
        <p class= "Hkname" ><h3><?php echo $stall_name; ?></h3></p>
        <p>Opening Hours: 8 a.m. - 9 p.m.</p>
        <p class= "Ctdetail" >Location: <?php echo $location; ?></p>
    </div>

<!-- like and dislike vote (also displays total number of votes accordingly) -->
    <!-- <div class="container">
        <div class="vote">
            <button id="like">
                <i class="fa fa-thumbs-up"></i>
            </button>
            <input type="number" id="likes" value="0" name="">
            <button id="dislike">
                <i class="fa fa-thumbs-down"></i>
            </button>
            <input type="number" id="dislikes" value="0" name="">
        </div>
    </div> -->

<!-- chef's recommendation -->
    <!-- <div class="recommendation">
        <ul>
            <li><div class="square-rounded">
                <img src="#hwkfoodimg" alt="hwk-img">
            </div></li>
            <li>food name</li>
            <li>price</li>
        </ul>
    </div> -->
<!-- catalogue -->
<div class="menu-section">
    <?php 
        $query1 = "SELECT * FROM catalogue WHERE stall_name = '$stallName' ";
        $result= mysqli_query($conn, $query1);
        if(mysqli_num_rows($result) > 0){
            while($row=mysqli_fetch_array($result)) {
    ?>
    <div class="menu">
        <button type="btn" class="collapsible">
            <img src="<?php echo $row["food_img"]; ?>" alt="food pic">
            <p class= "food"> <?php echo $row['foodName']; ?> </p>
            <p class= "food"> <?php echo $row['foodPrice']; ?> </p>
        </button>

        <div class="description">
            <form method = "post" action= "hawker-menu.php?stall_name=<?php echo $stall_name; ?>&action=add&foodID=<?php echo $row['foodID']; ?>">
                <p class= "desc" > <?php echo $row['foodDesc']; ?> </p>
                <input type="text" name="quantity" value="1" class="form-control" />
                <input type="hidden" name="hidden_foodName" value=" <?php echo $row['foodName']; ?>"/>
                <input type="hidden" name="hidden_foodPrice" value= " <?php echo $row['foodPrice']; ?>"/>
                <button type="submit" class="rectangle-rounded" name="cart">Add to Cart</button>
            </form>
        </div>
    </div>
    <?php
            }
        }
    ?>
</div>

</body>
</html>

<script>
  var coll = document.getElementsByClassName("collapsible");
  var i;

  for (i = 0; i < coll.length; i++) {
    coll[i].addEventListener("click", function () {
      this.classList.toggle("active");
      var content = this.nextElementSibling;
      if (content.style.maxHeight) {
        content.style.maxHeight = null;
      } else {
        content.style.maxHeight = content.scrollHeight + "px";
      }
    });
  }
</script>