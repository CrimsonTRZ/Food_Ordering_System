<?php
  include'config.php';

  error_reporting(0);

  session_start();

  if(!isset($_SESSION['Uname'])) {
    header("Location: index.php");
  }else {
        $Uname = $_SESSION['Uname'];
  }
  

  $sql = "SELECT * FROM user WHERE username = '$Uname' ";
  $db = mysqli_query($conn, $sql);
  while ($result = mysqli_fetch_assoc($db)) {
    $userID = $result['userID'];
    $sql1 = mysqli_query($conn, "SELECT * FROM application_form apli WHERE userID = $userID ");
    while ($row = mysqli_fetch_assoc($sql1)){
      $stallName = $row['stall_name'];
      $hawk_img = $row['hawk_img'];
      $location = $row['pickup_address'] . ", " . $row['postal_code'] . " " . $row['city'] . ", " . $row['state'];
    }
  }

 // add food into catalogue
 if (isset($_POST['confirm'])) {
  // upload image file
  $name = $_FILES['file']['name'];
  $target_dir = "img/";
  $target_file = $target_dir . basename($_FILES["file"]["name"]);
  $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
  $extensions_arr = array("jpeg");
  if( in_array($imageFileType,$extensions_arr) ){
    if(move_uploaded_file($_FILES['file']['tmp_name'],$target_dir.$name)){
      $image_base64 = base64_encode(file_get_contents('img/'.$name) );
      $foodPic = 'data:image/'.$imageFileType.';base64,'.$image_base64;
    }
  }
  $foodName = $_POST['add_foodName'];
  $price = $_POST['add_price'];
  $desc = $_POST['add_desc'];
  $sql = mysqli_query($conn, "SELECT * FROM catalogue WHERE foodName = '$foodName' ");
  if (!$sql->num_rows > 0){
    $query = mysqli_query($conn, "INSERT INTO `catalogue`(`stall_name`, `foodName`, `foodPrice`, `foodDesc`, `food_img`) VALUES ('$stallName','$foodName','$price','$desc','".$foodPic."') ");
    echo '<script>alert("Food added to catalogue.")</script>';
  }
}

  // update food info in catalogue table
  if(isset($_POST['edit'])){
    $foodID = $_GET['foodID'];
    $foodName = $_POST['foodName'];
    $price = $_POST['price'];
    $desc = $_POST['desc'];

    $query = mysqli_query($conn, "SELECT * FROM catalogue WHERE foodID = '$foodID' ");
    if ($query -> num_rows > 0) {
      $query1 = "UPDATE catalogue SET foodName = '$foodName', foodPrice = '$price', foodDesc = '$desc' WHERE foodID = '$foodID' ";
      $db1 = mysqli_query($conn, $query1);
      echo '<script>alert("Food details updated.")</script>';
    }
  }

  // delete food info in catalogue table
  if(isset($_POST['remove'])){
    $foodID = $_GET['foodID'];
    $query = mysqli_query($conn, "SELECT * FROM catalogue WHERE foodID = '$foodID' ");
    if ($query -> num_rows > 0) {
      $query1 = "DELETE FROM catalogue WHERE foodID = '$foodID' ";
      $db1 = mysqli_query($conn, $query1);
      echo '<script>alert("Food item have been removed.")</script>';
    }
  }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hawker Stall - menu page</title>
    <script src="https://kit.fontawesome.com/a0eb58ef8d.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="mod-menu.css">
</head>
<style>
    
</style>
<body>

    <!-- universal nav bar -->
    <nav>
      <div class="logo">
        <a href="#"><img src="img/logo.jpeg" alt="logo" /></a>
      </div>
      <li class="logoname">Grubs4Grabs</li>
      <ul>
        <div>
            <li><a href="mod-menu.php">Menu</a></li>
            <li><a href="hawker-order.php">Order</a></li>
            <li><a href="hwk_order_hist.php">Order History</a></li>
            <li><a href="hawker_PD.php">Profile</a></li>
        </div>
        <li id="signout"><a href="logout.php">Sign Out</a></li>
      </ul>
    </nav>
    
<!-- category content (hawkers img and name) -->
    <div class="circle">
      <img src="<?php echo $hawk_img; ?>" alt="hawker pic"><br>
    </div>
    <div class="content">
        <div class="hawker-detail">
            <p><h3><?php echo $stallName;?></h3></p> 
            <p>Opening Hours: 8 a.m. - 9 p.m.</p>
            <p name="location">Location: <?php echo $location;?> </p> 
        </div>
    </div>

  <!-- Add Menu -->

    <div class="Add-Section">
        <div class="Add-Menu">
        <h3>Add Menu:</h3>
            <div class="Add-Setting">
                <form action="" method="POST" enctype='multipart/form-data'>
                  <label for="food-img" id="food-img">Add Image: </label><br>
                  <input type="file" accept=".jpeg" name="file" placeholder ="Add Img Here" ><br><br>
                  <input type="text" id="Food_Name" name="add_foodName" placeholder="Add Food Name"><br>
                  <input type="text" id="Add_Price" name="add_price" placeholder="Add Price"><br><br><br>
                  <label for="Add_Description" id="food-description1">Add Description: </label><br>
                  <textarea name="add_desc" id="Add_Description" cols="50" rows="5" required></textarea><br>
                  <button type="submit" name="confirm" class="add-menu-button">Confirm</button>
                </form>
            </div>
        </div>


        
        <!-- Edit Menu -->
        <div class="Add-Menu">
            <h3>Menu: </h3>
            <?php
              $query = "SELECT * FROM catalogue WHERE stall_name = '$stallName' ";
              $result = mysqli_query($conn, $query);
              if(mysqli_num_rows($result) > 0){
              while($row=mysqli_fetch_array($result)) {
            ?>
			      <div class="Add-Setting">
              <form method = "post" action= "mod-menu.php?foodID=<?php echo $row['foodID']; ?>">
                <img id="added-img" src="<?php echo $row['food_img']; ?>" alt="food pic"><br><br>
                <input type="text" class="food" name="foodName" value="<?php echo $row['foodName']; ?>" required><br>
                <input type="number" step="0.01" min="0" class="price" name="price" value="<?php echo number_format($row['foodPrice'], 2); ?>" required><br><br><br>
                <label id="food-description2" for="description">Description: </label><br>
                <textarea name="desc" class="Add_Description" cols="50" rows="5" required><?php echo $row['foodDesc']; ?></textarea><br>
                <button type="submit" class="Save-Changes" name="edit">Save Changes</button>
                <button type="submit" class="Remove-Item" name="remove">Remove Item</button>         
              </form>
            </div>
            <?php
                }
            }
        ?>
          </div>

      
    </div>       


   <script>
       var coll = document.getElementsByClassName("collapsible");
       var i;
 
       for (i = 0; i < coll.length; i++) {
         coll[i].addEventListener("click", function () {
           this.classList.toggle("active");
           var content = this.nextElementSibling;
           if (content.style.maxHeight) {
             content.style.maxHeight = null;
           } else {
             content.style.maxHeight = content.scrollHeight + "px";
           }
         });
       }
     </script>
</body>
</html>
