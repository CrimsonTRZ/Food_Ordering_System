<?php
    include'config.php';
    
    error_reporting(0);

    session_start();

    if(!isset($_SESSION['Uname'])) {
        header("Location: index.php");
    } else {
        $Uname = $_SESSION['Uname'];
    }

    $query = "SELECT u.*, hol.* FROM user u, hawk_order_list hol WHERE u.userID = hol.userID AND u.username= '$Uname'";
    $db= mysqli_query($conn, $query);
    while($result=mysqli_fetch_assoc($db)){
        $userID = $result['userID'];
    }

    // Insert all food into order history & remove from order list.
    if (isset($_POST['done'])) {
      $hawkOR_ID = $_GET['hawkOR_ID'];
      $query = mysqli_query($conn, "SELECT COUNT(foodID) AS total_items FROM hawk_order_detail WHERE hawkOR_ID = '$hawkOR_ID' ");
      while ($data = mysqli_fetch_assoc($query)) {
          $total_items = $data['total_items'];
          $query1 = mysqli_query($conn, "SELECT * FROM hawk_order_list WHERE hawkOR_ID = '$hawkOR_ID' ");
          while ($result = mysqli_fetch_assoc($query1)){
            $subtotal = $result['subtotal'];
          }
      }

      $query = "INSERT INTO hawk_order_hist (`userID`, `total_items`, `subtotal`) VALUES ('$userID', '$total_items', '$subtotal')";
      $db = mysqli_query($conn, $query);
      
      $sql = "SELECT * FROM hawk_order_hist WHERE userID = '$userID' ";
      $db = mysqli_query($conn, $sql);
      while ($result = mysqli_fetch_assoc($db)) {
          $hawkOH_ID = $result['hawkOH_ID'];
          }

      $query = "SELECT hol.*, hod.* FROM hawk_order_list hol, hawk_order_detail hod WHERE hol.hawkOR_ID = hod.hawkOR_ID AND hod.hawkOR_ID = '$hawkOR_ID' ";
      $db = mysqli_query($conn, $query);   
      if(mysqli_num_rows($db) > 0){
          while($row= mysqli_fetch_array($db)) {
              $foodID = $row['foodID'];
              $quantity = $row['quantity'];
              $total = $row['total'];
              $query1 = "INSERT INTO hawk_order_hist_detail ( `hawkOH_ID`, `foodID`, `quantity`, `total`)
                          VALUES ('$hawkOH_ID', '$foodID', '$quantity', '$total') "; 
              $db1 = mysqli_query($conn, $query1);
          }
      }
      $query = "DELETE hol.*, hod.* FROM hawk_order_list hol, hawk_order_detail hod WHERE hol.hawkOR_ID = hod.hawkOR_ID AND hol.hawkOR_ID = '$hawkOR_ID' ";
      $db = mysqli_query($conn, $query);
      echo '<script>alert("Proceed to Payment to confirm order.")</script>';
      header('location: hawker-order.php');
    }

?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Order(Hawker)</title>
    <link rel="stylesheet" type="text/css" href="hawker-order.css" />
    <script
      src="https://kit.fontawesome.com/a0eb58ef8d.js" crossorigin="anonymous"></script>
  </head>
  <body>
    <!-- universal nav bar -->
    <nav>
      <div class="logo">
      <a href="#"><img src="img/logo.jpeg" alt="logo" /></a>
      </div>
      <li class="logoname">Grubs4Grabs</li>
      <ul>
        <div>
            <li><a href="mod-menu.php">Menu</a></li>
            <li><a href="hawker-order.php">Order</a></li>
            <li><a href="hwk_order_hist.php">Order History</a></li>
            <li><a href="hawker_PD.php">Profile</a></li>
        </div>
        <li id="signout"><a href="logout.php">Sign Out</a></li>
      </ul>
  </nav>

  <!-- main content -->
    <div class="background-layer">
      <?php
          $sql = "SELECT HOL.*, HOD.* FROM hawk_order_list HOL, hawk_order_detail HOD WHERE HOL.hawkOR_ID = HOD.hawkOR_ID AND  HOL.userID = '$userID' GROUP BY HOL.hawkOR_ID";
          $db = mysqli_query($conn, $sql);
          while ($result = mysqli_fetch_array($db)) {
      ?>
        <h2>Order - <?php echo $result['hawkOR_ID'];?> </h2>
        <table>
          <tr>
            <th>Item(s)</th>
            <th>Quantity</th>
            <th>Total Price</th>
          </tr>
          <?php
            $hawkOR_ID = $result['hawkOR_ID'];
            $sql = mysqli_query($conn, "SELECT ctl.*, hod.* FROM catalogue ctl, hawk_order_detail hod WHERE ctl.foodID = hod.foodID AND hod.hawkOR_ID = '$hawkOR_ID'");
            while ($row = mysqli_fetch_array($sql)) {
        ?>
          <tr>
            <td style="text-align:left;"><?php echo $row['foodName'];?></td>
            <td><?php echo $row['quantity'];?></td>
            <td>RM <?php echo $row['total'];?></td>
          </tr>
          <?php
            }
          ?>
        </table>
        <form action="hawker-order.php?hawkOR_ID=<?php echo $hawkOR_ID; ?>" method="post">
        <button type="submit" name="done" style="float: right;" class="button1">
          <a>Done</a>
        </button>
        </form>
        <hr>
        <?php
          }
        ?>
      
    </div>
  </body>
</html>
