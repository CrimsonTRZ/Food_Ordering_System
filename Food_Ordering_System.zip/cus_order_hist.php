<?php
    include'config.php';
    
    error_reporting(0);
    
    session_start();
 
    if (isset( $_SESSION['stallName'])) {
        $stallName = $_SESSION['stallName'];
    }

    if(!isset($_SESSION['Uname'])) {
        header("Location: index.php");
    } else {
        $Uname = $_SESSION['Uname'];
    }

    // Search function (search by category and stall name)
    if (isset($_POST['lookup'])) {
      $search = mysqli_real_escape_string($conn, $_POST['search']);
      $query = mysqli_query($conn, "SELECT * FROM category WHERE category_name  LIKE '%$search%' ");
      $result = mysqli_num_rows($query);
      if ($result > 0) {
          while($row = mysqli_fetch_assoc($query)){
              $ctgID = $row['categoryID'];
              if ($ctgID) {
                  echo '<script>window.location="Category.php?categoryID='.$ctgID.'"</script>';
              }
          }
      }
      $query1 = mysqli_query($conn, "SELECT * FROM application_form WHERE stall_name LIKE '%$search%' ");
      $result1 = mysqli_num_rows($query1);
      if ($result1 > 0) {
          while($row = mysqli_fetch_assoc($query1)){
              $stallName = $row['stall_name'];
              if ($stallName) {
                  echo '<script>window.location="hawker-menu.php?stall_name='.$stallName.'"</script>';
              }
          }
      } else {
          echo "<script>alert('Search result not found. Please try another keyword.')</script>";
      }
    }

    $query = "SELECT u.*, coh.* FROM user u, cus_order_hist coh WHERE u.userID = coh.userID AND u.username= '$Uname' ";
    $db= mysqli_query($conn, $query);
    while($result=mysqli_fetch_assoc($db)){
        $userID = $result['userID'];
        $location = $result['street_address'] . ", " . $result['postal_code'] . " " . $result['city'] . ", " . $result['state'];
    }

    if (isset($_POST['confirmDate'])) {
      $date = filter_input(INPUT_POST, 'date', FILTER_SANITIZE_STRING);
    } else {
      echo '<script>alert("No date selected. Please select date to view order history.")</script>';
    }

    $sql = "SELECT u.*, coh.* FROM user u, cus_order_hist coh WHERE u.userID = coh.userID AND coh.userID = '$userID' AND orderDate = '$date' ";
    $result = mysqli_query($conn, $sql);
    while ($row = mysqli_fetch_assoc($result)) {
      $orderID = $row['orderID'];
      $total_items = $row['total_items'];
      $subtotal = $row['subtotal'];
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Order History (Customer)</title>
  <link rel="stylesheet" type="text/css" href="cus_order_hist.css" />
  <script
    src="https://kit.fontawesome.com/a0eb58ef8d.js"
    crossorigin="anonymous"
  ></script>

</head>
<body>
   <!-- universal nav bar -->
   <nav>
        <div class="logo">
          <a href="#"><img src="img/logo.jpeg" alt="logo" /></a>
        </div>
        <li class="logoname">Grubs4Grabs</li>
        <ul>
          <div>
            <li><a href="mainpage.php">Home Page</a></li>
            <li><a href="personal-details.php">Profile</a></li>
            <li><a href="cart.php">Cart</a></li>
            <li><a href="join-family.php">Join Our Family</a></li>
            <li><a href="register.php">Sign Up</a></li>
            <li><a href="index.php">Login</a></li>
            <li><a href="logout.php">Sign Out</a></li>
          </div>
          <form action="" class="searchbar" method="post">
          <input type="search" placeholder="Search.." name="search" />
          <button type="submit" name="lookup" id="lookup">
            <i class="fas fa-search"></i>
          </button>
        </form>
        </ul>
    </nav>

    <!-- Logout modal -->
    <div class="modal" id="logout">
      <div class="modal-content">
        <div class="modal-header">
          SIGN OUT
          <button class="icon modal-close">
            <i class="fas fa-times"></i>
          </button>
        </div>
      <div class="modal-body">Do you wish to sign out?</div>
        <div class="modal-footer">
          <button class="link modal-close">No</button>
          <button class="confirm">Yes</button>
        </div>
      </div>
    </div>

    <!-- universal side nav -->
    <div class="circle-box">
        <center>
            <div class="circle">
                <img src="img/avatar.jpg" alt="profile picture" />
            </div>
        </center>
    </div>
    <div class="sidenav">
        <ul>
            <li><a href="cart.php">My Cart</a></li>
            <li><a href="cus_order_hist.php">Order History</a></li>
            <li><a href="personal-details.php">Personal Details</a></li>
            <li>
                <a class="modal-open" data-modal="logout" id="signout">Sign Out</a>
            </li>
        </ul>
    </div>

<!-- Main content (order history) -->
    <div class="content">
      <div class="date-section">
        <div class="heading1">
          <h3>Order History</h3>
        </div>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']) ?>">
          <label for="date">Date:</label>
          <select name="date" id="date">
            <?php
                $sql = "SELECT * FROM cus_order_hist WHERE userID = '$userID' ";
                $db = mysqli_query($conn, $sql);
                while ($result = mysqli_fetch_array($db)) {
            ?>
              <option value="<?php echo $result['orderDate']; ?>" <?php echo($result['orderDate'] == $date?"selected":""); ?>> 
                <?php echo $result['orderDate']; ?>
              </option>
            <?php
                }
            ?>
          </select>
          <button type="submit" name="confirmDate" id="select-date-button">Select Date</button>
        </form>
      </div>
    </div>
    <!-- content of order history -->
    <div class="History-section">
      <div class="History-list">
        <button class="collapsible">
          <table>
            <tr>
              <td>Order ID</td>
              <td>Total items</td>
              <td>Subtotal</td>
            </tr>

            <tr>
              <td><?php echo $orderID; ?></td>
              <td><?php echo $total_items; ?></td>
              <td><?php echo $subtotal; ?></td>
            </tr>
          </table>
        </button>
        <div class="History-table">
          <table>
            <tr>
              <th>Item</th>
              <th>Quantity</th>
              <th>Total Price</th>
            </tr>
            <?php
              $sql = "SELECT ctl.*, cod.* FROM catalogue ctl, cus_order_detail cod WHERE ctl.foodID = cod.foodID AND cod.orderID = '$orderID' ";
              $result = mysqli_query($conn, $sql);
              if(mysqli_num_rows($result) > 0){
                  while($row= mysqli_fetch_array($result)) {
            ?>
            <tr>
              <td><?php echo $row['foodName']; ?></td>
              <td><?php echo $row['quantity']; ?></td>
              <td><?php echo $row['total']; ?></td>
            </tr>
            <?php
                  }
                }
            ?>
          </table>
        </div>
      </div>
    </div>  
</body>
</html>

<script>
      var coll = document.getElementsByClassName("collapsible");
      var i;

      for (i = 0; i < coll.length; i++) {
        coll[i].addEventListener("click", function () {
          this.classList.toggle("active");
          var content = this.nextElementSibling;
          if (content.style.maxHeight) {
            content.style.maxHeight = null;
          } else {
            content.style.maxHeight = content.scrollHeight + "px";
          }
        });
      }
</script>

<script>
  var modalBtns = document.querySelectorAll(".modal-open");

  modalBtns.forEach(function (btn) {
    btn.onclick = function () {
      var modal = btn.getAttribute("data-modal");

      document.getElementById(modal).style.display = "block";
    };
  });

  var closeBtns = document.querySelectorAll(".modal-close");

  closeBtns.forEach(function (btn) {
    btn.onclick = function () {
      var modal = (btn.closest(".modal").style.display = "none");
    };
  });
</script>

<script>
  var logoutBtn = document.querySelectorAll(".confirm");

  logoutBtn.forEach(function (btn) {
    btn.onclick = function () {
      window.location = "logout.php"
    };
  });
</script>