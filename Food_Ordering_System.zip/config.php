<?php

$server = "localhost:3306";
$username = "root";
$password = "";
$database = "wdt_assignment";

$conn = mysqli_connect($server, $username, $password, $database);

if (!$conn) {
    die("<script>alert('Unable to connect to server.')</script>");
}

?>