<?php
    include'config.php';
    
    error_reporting(0);

    session_start();

    if(!isset($_SESSION['Uname'])) {
        header("Location: index.php");
    } else {
        $Uname = $_SESSION['Uname'];
    }

    $sql = "SELECT * FROM user WHERE username = '$Uname' ";
    $db = mysqli_query($conn, $sql);
    while($result=mysqli_fetch_assoc($db)){
      $userID = $result['userID'];
      $Uname = $result['username'];
      $phone = $result['phone_number'];
      $email = $result['email_address'];
    }

    if (isset($_POST['UpdtInfo'])) {
      $new_Uname = $_POST['username'];
      $new_phone = $_POST['phone'];
      $new_email = $_POST['email'];
      $query = "UPDATE `user` SET `username`='$new_Uname',`phone_number`='$new_phone',`email_address`='$new_email' WHERE userID = '$userID' ";
      $result = mysqli_query($conn, $query);
      $_SESSION['Uname'] = $new_Uname;
      echo '<script>alert("Changes Saved!")</script>';
      echo '<script>window.location="admin_PD.php"</script>';
    }
?>

<!DOCTYPE html>
<html>
    <head>
        <title>Admin personal detail</title>
        <link rel="stylesheet" type="text/css" href="admin_PD.css" />
        <script src="https://kit.fontawesome.com/a0eb58ef8d.js" crossorigin="anonymous"></script>
    </head>
    <body>
        <!-- universal nav bar -->
    <nav>
        <div class="logo">
        <a href="#"><img src="img/logo.jpeg" alt="logo" /></a>
        </div>
        <li class="logoname">Grubs4Grabs</li>
        <ul>
        <div>
            <li><a href="admin_account.php">Accounts</a></li>
            <li><a href="admin_PD.php">User Profile</a></li>
        </div>
        <li id="signout"><a href="logout.php">Sign Out</a></li>
        </ul>
    </nav>

    <!-- main content -->
    <center><h2>Admin User Profile</h2></center>
    <div class="admin-profile">
        <form action="" method="post">
            <center>
                <div class="image-cropper">
                    <img src="img/avatar.jpg" alt="profile picture" />
                </div>
            </center>
            <ul style="list-style-type: none;">
            <label for="username">Username: </label>
            <input type="text" name="username" id="username" maxlength="50" value="<?php echo $Uname; ?>" required/><br />
            <label for="phone">Phone Number: </label>
            <input type="tel" name="phone" id="phone" pattern="[0-9]{11}" value="<?php echo $phone; ?>" required/><br />
            <label for="email">Email: </label>
            <input type="email" name="email" id="email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2, 4}$" value="<?php echo $email; ?>" required/><br />
            
            <center><button type="submit" name="UpdtInfo" id="update-button">Save</button></center>
        </form>
    </div>

    </body>
</html>