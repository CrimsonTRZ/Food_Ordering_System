<?php
    include'config.php';
    
    error_reporting(0);

    session_start();

    if(!isset($_SESSION['Uname'])) {
        header("Location: index.php");
    } else {
        $Uname = $_SESSION['Uname'];
    }

  // Search function (search by category and stall name)
    if (isset($_POST['lookup'])) {
      $search = mysqli_real_escape_string($conn, $_POST['search']);
      $query = mysqli_query($conn, "SELECT * FROM category WHERE category_name  LIKE '%$search%' ");
      $result = mysqli_num_rows($query);
      if ($result > 0) {
          while($row = mysqli_fetch_assoc($query)){
              $ctgID = $row['categoryID'];
              if ($ctgID) {
                  echo '<script>window.location="Category.php?categoryID='.$ctgID.'"</script>';
              }
          }
      }
      $query1 = mysqli_query($conn, "SELECT * FROM application_form WHERE stall_name LIKE '%$search%' ");
      $result1 = mysqli_num_rows($query1);
      if ($result1 > 0) {
          while($row = mysqli_fetch_assoc($query1)){
              $stallName = $row['stall_name'];
              if ($stallName) {
                  echo '<script>window.location="hawker-menu.php?stall_name='.$stallName.'"</script>';
              }
          }
      } else {
          echo "<script>alert('Search result not found. Please try another keyword.')</script>";
      }
    }

    $sql = "SELECT * FROM user WHERE username = '$Uname' ";
    $db = mysqli_query($conn, $sql);
    while($result=mysqli_fetch_assoc($db)){
      $userID = $result['userID'];
      $Uname = $result['username'];
      $phone = $result['phone_number'];
      $email = $result['email_address'];
      $streetAdd = $result['street_address'];
      $postal = $result['postal_code'];
      $city = $result['city'];
      $state = $result['state'];
      $DOB = $result['Date_of_Birth'];
    }

    if (isset($_POST['updateInfo'])) {
      $new_Uname = $_POST['username'];
      $new_phone = $_POST['phone'];
      $new_email = $_POST['email'];
      $new_streetAdd = $_POST['address'];
      $new_postal = $_POST['postal'];
      $new_city = $_POST['city'];
      $new_state = $_POST['state'];
      $new_DOB = $_POST['DOB'];
      $query = "UPDATE `user` SET `username`='$new_Uname',`phone_number`='$new_phone',`email_address`='$new_email',`street_address`='$new_streetAdd',`postal_code`='$new_postal',`city`='$new_city',`state`='$new_state',`Date_of_Birth`='$new_DOB'
       WHERE userID = '$userID' ";
      $result = mysqli_query($conn, $query);
      $_SESSION['$Uname'] = $new_Uname;
      echo '<script>alert("Changes Saved!")</script>';
      echo '<script>window.location="personal-details.php"</script>';
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Personal Details</title>
  <link rel="stylesheet" href="personal-details.css" />
  <script
    src="https://kit.fontawesome.com/a0eb58ef8d.js"
    crossorigin="anonymous"
  ></script>
</head>
<body>
    <!-- universal nav bar -->
  <nav>
      <div class="logo">
        <a href="#"><img src="img/logo.jpeg" alt="logo" /></a>
      </div>
      <li class="logoname">Grubs4Grabs</li>
      <ul>
        <div>
          <li><a href="mainpage.php">Home Page</a></li>
          <li><a href="personal-details.php">Profile</a></li>
          <li><a href="cart.php">Cart</a></li>
          <li><a href="join-family.php">Join Our Family</a></li>
          <li><a href="register.php">Sign Up</a></li>
          <li><a href="index.php">Login</a></li>
          <li><a href="logout.php">Sign Out</a></li>
        </div>
        <form action="" class="searchbar" method="post">
          <input type="search" placeholder="Search.." name="search" />
          <button type="submit" name="lookup">
            <i class="fas fa-search"></i>
          </button>
        </form>
      </ul>
  </nav>

    <!-- Logout modal -->
    <div class="modal" id="logout">
      <div class="modal-content">
        <div class="modal-header">
          SIGN OUT
          <button class="icon modal-close">
            <i class="fas fa-times"></i>
          </button>
        </div>
      <div class="modal-body">Do you wish to sign out?</div>
        <div class="modal-footer">
          <button class="link modal-close">No</button>
          <button class="confirm">Yes</button>
        </div>
      </div>
    </div>

    <!-- sidebar -->
    <div class="circle-box">
        <center>
            <div class="circle">
                <img src="img/avatar.jpg" alt="profile picture" />
            </div>
        </center>
    </div>
    <div class="sidenav">
        <ul>
            <li><a href="cart.php">My Cart</a></li>
            <li><a href="cus_order_hist.php">Order History</a></li>
            <li><a href="personal-details.php">Personal Details</a></li>
            <li>
                <a class="modal-open" data-modal="logout" id="signout">Sign Out</a>
            </li>
        </ul>
    </div>

<!-- Main content -->
    <div class="content">
      <div class="user-profile">
        <form action="" method="POST">
          <label for="username">Username: </label>
          <input
            type="text"
            name="username"
            id="username"
            maxlength="50"
            value="<?php echo $Uname; ?>"
            required
          /><br />
          <label for="phone">Phone Number: </label>
          <input
            type="tel"
            name="phone"
            id="phone"
            pattern="[0-9]{11}"
            value="<?php echo $phone; ?>"
          /><br />
          <label for="email">Email: </label>
          <input
            type="email"
            name="email"
            id="email"
            pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2, 4}$"
            value="<?php echo $email; ?>"
            required
          /><br />
          <label for="DOB">Date of Birth: </label>
          <input type="text" name="DOB" id="DOB" onfocus="(this.type='date')" onblur="(this.type='text')" value="<?php echo $DOB; ?>" required /><br />
          <label for="address">Street Address: </label>
          <input type="text" name="address" value="<?php echo $streetAdd; ?>" required /><br />
          <label for="postal">Postal Code: </label>
          <input type="number" min="10000" maxlength="99999" name="postal" value="<?php echo $postal; ?>" required /><br />
          <label for="city">City: </label>
          <input type="text" name="city" value="<?php echo $city; ?>" required /><br />
          <label for="state">State: </label>
          <input type="text" name="state" value="<?php echo $state; ?>" required /><br />
          <div class="edit-profile">
            <button type="submit" name="updateInfo">Save Changes</button>
          </div>
        </form>
      </div>
    </div>
  </body>
</html>

<script>
      var modalBtns = document.querySelectorAll(".modal-open");

      modalBtns.forEach(function (btn) {
        btn.onclick = function () {
          var modal = btn.getAttribute("data-modal");

          document.getElementById(modal).style.display = "block";
        };
      });

      var closeBtns = document.querySelectorAll(".modal-close");

      closeBtns.forEach(function (btn) {
        btn.onclick = function () {
          var modal = (btn.closest(".modal").style.display = "none");
        };
      });
</script>

<script>
  var logoutBtn = document.querySelectorAll(".confirm");

  logoutBtn.forEach(function (btn) {
    btn.onclick = function () {
      window.location = "logout.php"
    };
  });
</script>